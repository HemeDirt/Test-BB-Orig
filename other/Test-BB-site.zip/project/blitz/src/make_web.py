# -*- coding: utf-8 -*-
"""Генерирует web/index.html — интерактивная страница игры БЛИЦ БОЙ (все данные вшиты)."""
import sys, io, json, random, os, datetime
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

def run_game(seed):
    """Один импорт, вызов партии как функции — без argv-хаков и subprocess."""
    import game_sim as gs
    res = gs.play_game(seed)
    data = {
        'seed': seed, 'log': res['log'],
        'state': {k: v for k, v in res['state'].items()},
        'players': [{'seat': p['seat'], 'name': p['name'], 'prof': list(p['prof']),
                     'alive': p['alive'], 'or': p['or'], 'died_cycle': p['died_cycle'],
                     'tokens': p['tokens'], 'kills': p['kills'],
                     'revealed': [[k, c] for k, c in p['revealed']],
                     'spec_used': p['spec_used'],
                     'pers': dict(p.get('pers') or {}),
                     'rep': {str(k): v for k, v in (p.get('rep') or {}).items()},
                     'grudge': {str(k): v for k, v in (p.get('grudge') or {}).items()}}
                    for p in res['players']],
        'arch_ru': getattr(gs, 'ARCH_RU', {}),
    }
    return data, {'PROFS': [list(x) for x in gs.PROFS], 'SPECS': [list(x) for x in gs.SPECS],
                  'TENY': [list(x) for x in gs.TENY], 'OBMEN': [list(x) for x in gs.OBMEN],
                  'DECKS': gs.DECKS}

def parse_args(argv):
    """Понимает и 'make_web.py 5', и 'blitz.py web --seed 5'."""
    seed = 777
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '--seed':
            seed = int(argv[i + 1]); i += 2
        elif a.startswith('--seed='):
            seed = int(a.split('=', 1)[1]); i += 1
        elif a.isdigit():
            seed = int(a); i += 1
        else:
            i += 1  # незнакомые флаги молча пропускаем
    return seed

seed = parse_args(sys.argv[1:])
data, cards = run_game(seed)
html = open(os.path.join(ROOT, 'template_index.html'), encoding='utf-8').read()
html = html.replace('/*__DATA__*/null', json.dumps(data, ensure_ascii=False))
html = html.replace('/*__CARDS__*/null', json.dumps(cards, ensure_ascii=False))
# результат — в docs/preview/index.html (это и есть будущий сайт GitHub Pages)
out = os.path.join(ROOT, '..', 'docs', 'preview', 'index.html')
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, 'w', encoding='utf-8').write(html)
print(f'OK: {out} ({len(html)//1024} КБ), seed={seed}, log={len(data["log"])} строк')
