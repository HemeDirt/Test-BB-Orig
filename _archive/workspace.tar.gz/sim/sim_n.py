# -*- coding: utf-8 -*-
"""Обобщённый симулятор партии «БЛИЦ БОЙ»: N игроков (2..20) и варианты ситуаций.
Механики идентичны sim/game_sim.py (редакция правил 3.1), лог компактнее.
Usage: python3 sim/sim_n.py SEED N [VARIANT] [--quiet]
VARIANT: base | plane | tomato | pole | purg | amkary | hrono
В конце партии печатается строка STATS={json} — для массовых прогонов.
"""
import json, random, sys, math, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import game_sim as G   # берём только данные: POOLS, SPECS, TENY, OBMEN

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
N = int(sys.argv[2]) if len(sys.argv) > 2 else 8
VARIANT = sys.argv[3] if len(sys.argv) > 3 and not sys.argv[3].startswith('--') else 'base'
QUIET = '--quiet' in sys.argv

LOG = []
def log(s): LOG.append(s)

PROF_ACTIVE = G_PROFS = [
 ('Почтальон','получает в инвентарь посылку с рандомным предметом'),
 ('Стример','может вести стрим и собирать донаты'),
 ('Водитель','получает любую машину на выбор'),
 ('Вор','может украсть одну вещь за цикл, работает 3 раза'),
 ('Медик','может воскресить другого игрока'),
 ('Крупье','может перебросить кубик 1 раз за цикл'),
 ('Шизик','немного поехавший, но везучий'),
 ('Каскадёр','принимает на себя РП действие, направленное на другого (до броска)'),
]
PROF_PASSIVE = [
 ('Сантехник',''), ('Бухгалтер',''), ('Охранник',''), ('Повар',''),
 ('Таксист',''), ('Грузчик',''), ('Сварщик',''), ('Рыбак',''),
 ('Дворник',''), ('Продавец',''), ('Курьер',''), ('Плотник',''),
]
PROF_ALL = PROF_ACTIVE + PROF_PASSIVE

# расписания ситуаций: cycle -> (раскрытий, РПДС, РПДИ); forced = «рандомный выбор убийства» в конце 5-го цикла
SCHED = {
 'base':   {1:(2,1,1), 2:(1,1,1)},
 'plane':  {1:(1,1,0), 2:(2,1,1), 3:(3,1,1), 4:(0,0,1), 5:(1,0,1)},
 'tomato': {1:(2,1,0), 2:(1,1,1), 3:(2,1,1), 4:(0,0,1), 5:(1,1,1)},
 'pole':   {1:(3,1,0), 2:(2,1,1), 3:(1,1,1), 4:(0,0,1), 5:(1,1,1)},
 'purg':   {1:(3,0,1), 2:(1,1,1), 3:(1,1,2), 4:(0,0,1), 5:(1,1,1)},
 'amkary': {1:(2,1,0), 2:(2,1,1), 3:(2,1,1), 4:(0,0,1), 5:(1,1,1)},
 'amkary2':{1:(2,1,0), 2:(2,1,1), 3:(2,1,1), 4:(0,0,1), 5:(1,1,1)},
 'hrono':  {1:(2,0,2), 2:(1,1,1), 3:(1,1,1), 4:(2,1,2), 5:(1,1,2)},
}
FORCED_END = {'plane','tomato','pole','purg','amkary'}
VNAME = {'base':'«Ночь в панельке» (базовое расписание)','plane':'«Самолёт в Гренландию»',
         'tomato':'«Помидор, забывший тройку»','pole':'«Поле на остановке»',
         'purg':'«Чистилище»','amkary':'«Амкары и Касторама»','hrono':'«Пьяная хронология»',
         'amkary2':'«Амкары: режим на уничтожение»'}

def sched(c):
    s = SCHED[VARIANT]
    if c in s: return s[c]
    return s[max(k for k in s if k <= c)]

rng = None
P, DRAW, STATE = [], {}, {}
DRAW_TENY = []

MODS = {}

def setup(seed, n, variant, mods=None):
    global rng, P, DRAW, STATE, DRAW_TENY, VARIANT, N, MODS
    MODS = dict(mods or {})
    VARIANT, N = variant, n
    rng = random.Random(seed)
    DRAW = {k: v[:] for k, v in G.POOLS.items()}
    for k in DRAW: rng.shuffle(DRAW[k])
    DRAW_TENY = G.TENY[:]; rng.shuffle(DRAW_TENY)
    profs = PROF_ALL[:]; rng.shuffle(profs)
    specs = G.SPECS[:]; rng.shuffle(specs)
    obmen = G.OBMEN[:]; rng.shuffle(obmen)
    P = []
    for i in range(n):
        hand = {k: [DRAW[k].pop()] for k in DRAW}
        p = dict(seat=i+1, name=f'Игрок {i+1}', prof=profs[i % len(profs)], hand=hand,
                 revealed=[], alive=True, spec=specs[i % len(specs)], spec_used=False,
                 spec_armed=False, tokens=0, ghostcard=None, ghost_used=set(), bet=None,
                 obmen=obmen[i % len(obmen)], heal_taken=0, thief_left=3, croupier_used_cycle=0,
                 immune=0, no_rpds=False, no_target=False, skip_reveal=False, buff=0,
                 debuff=False, died_cycle=None, resurrected=False, kills=0, dark_pen=0,
                 team=(i % 2 if variant in ('amkary','amkary2') else -1), or_=0)
        P.append(p)
    post = [p for p in P if p['prof'][0] == 'Почтальон']
    if post and DRAW['ИНВЕНТАРЬ']:
        post[0]['hand']['ИНВЕНТАРЬ'].append(DRAW['ИНВЕНТАРЬ'].pop())
    S = math.floor(n / 2)
    if variant in ('tomato', 'pole') and n in (3, 4): S = 2
    if MODS.get('s_plus1'): S += 1
    if MODS.get('s_third'): S = max(1, math.floor(n / 3))
    W = S
    if variant == 'purg':
        W = rng.randint(1, n)
        log(f'Мест в раю: бросок d{n} = {W}')
    STATE = dict(cycle=0, player_death=False, dark=False, last_wound=None, harvests=0,
                 bet_hits=0, token_revive=False, spec_revive=False, avoid_saved=False,
                 mass_count=0, nat1=False, nat20=False, first_death_cycle=None,
                 end_cycle=None, deaths=0, queue_shift=None, S=S, W=W, forced=False,
                 team_win=False, rotations=0, field_deaths=0, rolls={},
                 max_cycle_deaths=0, mods=dict(MODS))

def by_seat(s): return P[s-1]
def alive_list(): return [p for p in P if p['alive']]
def ghosts(): return [p for p in P if not p['alive']]
def d20():
    r = rng.randint(1, 20)
    STATE['rolls'][r] = STATE['rolls'].get(r, 0) + 1
    return r
def send(): return STATE['W'] if VARIANT == 'purg' else STATE['S']

def closed_cards(p):
    out = []
    for k, lst in p['hand'].items():
        for c in lst: out.append((k, c))
    return out

def reveal(p):
    if p['skip_reveal']:
        p['skip_reveal'] = False
        log(f'  P{p["seat"]}: раскрытие пропущено (Ладонь на глазах)')
        return None
    cc = closed_cards(p)
    if not cc: return None
    if STATE['cycle'] == 1 and not any(r[0] == 'ПРОФЕССИЯ' for r in p['revealed']):
        card = p['prof'][0] + (' - ' + p['prof'][1] if p['prof'][1] else '')
        p['revealed'].append(('ПРОФЕССИЯ', card))
        log(f'  P{p["seat"]} раскрывает [ПРОФЕССИЯ] {card}')
        return ('ПРОФЕССИЯ', card)
    k, c = rng.choice(cc)
    p['hand'][k].remove(c); p['revealed'].append((k, c))
    log(f'  P{p["seat"]} раскрывает [{k}] «{c}»')
    return (k, c)

def mod_roll(p, roll, kind):
    m = roll
    if p['buff'] and kind != 'mass':
        m += p['buff']; log(f'    (+{p["buff"]} от «Невидимого напарника»)'); p['buff'] = 0
    if STATE['dark'] and kind in ('рпди', 'mass'):
        m -= 1; p['dark_pen'] += 1
    return m

def croupier_reroll(actor, roll, kind):
    crs = [p for p in P if p['prof'][0] == 'Крупье' and p['alive']]
    if not crs: return roll
    cr = crs[0]
    if cr is actor or cr['croupier_used_cycle'] == STATE['cycle'] or roll >= 10: return roll
    if rng.random() < 0.55:
        cr['croupier_used_cycle'] = STATE['cycle']
        r2 = d20()
        log(f'    КРУПЬЕ P{cr["seat"]} перебрасывает чужой кубик {roll} → {r2}')
        return r2
    return roll

def wound(p, amt, src=''):
    if p['immune'] >= STATE['cycle'] and src not in ('self', 'поле'):
        log(f'    P{p["seat"]} НЕВОСПРИИМЧИВ: {amt} ОР не проходит')
        return False
    p['or_'] += amt
    STATE['last_wound'] = (p['seat'], amt)
    log(f'    P{p["seat"]}: +{amt} ОР → всего {p["or_"]}')
    if p['or_'] >= 3: check_death(p, 'ранения', src)
    return True

def check_death(p, cause, src=''):
    if not p['alive']: return
    if p['spec_armed'] and cause != 'жатва':
        p['spec_armed'] = False; p['spec_used'] = True; p['or_'] = 2
        STATE['avoid_saved'] = True
        log(f'    !!! P{p["seat"]} уходит от смерти: спецкарта «избежать смерти», ОР сброшены до 2')
        return
    p['alive'] = False; p['died_cycle'] = STATE['cycle']
    STATE['deaths'] += 1
    if STATE['first_death_cycle'] is None: STATE['first_death_cycle'] = STATE['cycle']
    if cause in ('жатва', 'поле', 'финал'):
        log(f'    💀 P{p["seat"]} УМИРАЕТ ({cause})')
    else:
        STATE['player_death'] = True
        log(f'    💀 P{p["seat"]} УМИРАЕТ ({cause}, источник: {src or "—"})')
    p['obmen'] = None

def table_A(p, roll, declared, target, kind='рпди'):
    nat = roll; eff = mod_roll(p, roll, kind)
    if nat == 20: STATE['nat20'] = True
    if nat == 1: STATE['nat1'] = True
    if nat == 1: eff = 1
    if nat == 20: eff = 20
    eff = croupier_reroll(p, eff, kind)
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [таблица А, {declared}]')
    if declared == 'УБИЙСТВО':
        if eff <= 4: log('    КРИТ-ПРОВАЛ: удар возвращается в автора'); check_death(p, 'крит-провал собственного убийства', p['name'])
        elif eff <= 8: wound(p, 1, 'свой провал')
        elif eff <= 12: log('    ничего не произошло')
        elif eff <= 16: wound(target, 2, p['name']); p['kills'] += 0
        else:
            log('    КРИТ: цель умирает сразу'); p['kills'] += 1
            check_death(target, 'крит убийства', p['name'])
    else:
        if eff <= 4: log('    КРИТ-ПРОВАЛ: +2 ОР автору'); wound(p, 2, 'self')
        elif eff <= 8: wound(p, 1, 'self')
        elif eff <= 12: log('    ничего не произошло')
        elif eff <= 16: wound(target, 1, p['name'])
        else: log('    КРИТ: +2 ОР цели'); wound(target, 2, p['name'])

def table_B(p, roll, action, on_succ, on_fail, kind='рпди'):
    nat = roll; eff = mod_roll(p, roll, kind)
    if nat == 20: eff = 20; STATE['nat20'] = True
    if nat == 1: eff = 1; STATE['nat1'] = True
    eff = croupier_reroll(p, eff, kind)
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [таблица Б, {action}]')
    if nat == 20 or (nat != 1 and eff >= 15): on_succ()
    elif nat == 1 or eff <= 10: on_fail()
    else: log('    ничего не произошло (11–14)')

def table_V(p, roll, action, on_succ, on_fail):
    nat = roll; eff = mod_roll(p, roll, 'рпдс')
    if nat == 20: eff = 20; STATE['nat20'] = True
    if nat == 1: eff = 1; STATE['nat1'] = True
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [таблица В, {action}]')
    if nat == 20 or (nat != 1 and eff >= 11): on_succ()
    elif nat == 1 or eff <= 9: on_fail()
    else: log('    ничего не произошло (10)')

def pick_target(p, need_dmg=False):
    if VARIANT == 'amkary' and rng.random() < 0.85:
        cands = [q for q in alive_list() if q is not p and q['team'] != p['team'] and not q['no_target']]
        if not cands: cands = [q for q in alive_list() if q is not p and not q['no_target']]
    else:
        cands = [q for q in alive_list() if q is not p and not q['no_target']]
    if not cands: cands = [q for q in alive_list() if q is not p]
    if not cands: return None
    if need_dmg:
        soft = [q for q in cands if q['or_'] <= 1]
        if soft and STATE['cycle'] == 1: cands = soft
    return rng.choice(cands)

def cascade_check(actor, target):
    if target is actor: return target
    cs = [p for p in P if p['prof'][0] == 'Каскадёр' and p['alive'] and p is not target and p is not actor]
    if cs and rng.random() < 0.4:
        c = cs[0]
        log(f'    КАСКАДЁР P{c["seat"]} объявляет до броска: принимает удар на себя!')
        return c
    return target

def do_steal(p, victim, use_prof=False):
    def succ():
        cc = closed_cards(victim)
        if not cc:
            rv = victim['revealed'][:]
            if not rv: log('    у цели пусто — красть нечего'); return
            k, c = rng.choice(rv); victim['revealed'].remove((k, c))
        else:
            k, c = rng.choice(cc); victim['hand'][k].remove(c)
        p['hand'].setdefault(k, []).append(c)
        log(f'    УСПЕХ: P{p["seat"]} забирает у P{victim["seat"]} закрытую карту [{k}]')
    def fail():
        cc = closed_cards(p)
        if cc:
            k, c = rng.choice(cc); p['hand'][k].remove(c)
            victim['hand'].setdefault(k, []).append(c)
            log(f'    ПРОВАЛ (обратный эффект): P{victim["seat"]} тянет вслепую у P{p["seat"]} карту [{k}]')
        else:
            log(f'    ПРОВАЛ: у P{p["seat"]} вся рука раскрыта — стол решает обратный эффект')
    table_B(p, d20(), 'кража', succ, fail)

def heal_ok(q):
    return q['heal_taken'] < 1 or MODS.get('healcap_off')

def do_heal_action(p, target):
    if not heal_ok(target):
        log(f'    лимит лечения P{target["seat"]} в цикле исчерпан — РПДИ сгорает')
        return
    def succ():
        target['or_'] = max(0, target['or_'] - 1); target['heal_taken'] += 1
        log(f'    УСПЕХ: P{target["seat"]} вылечен на 1 ОР → {target["or_"]}')
    def fail():
        log('    ПРОВАЛ (обратный эффект на автора): неумелая помощь')
        wound(p, 1, 'self')
    table_B(p, d20(), f'помощь P{target["seat"]}', succ, fail)

def do_humiliate(p, target):
    def succ():
        cc = closed_cards(target)
        if cc:
            k, c = rng.choice(cc); target['hand'][k].remove(c); target['revealed'].append((k, c))
            log(f'    УСПЕХ: P{target["seat"]} от позора раскрывает [{k}]')
        else:
            log('    УСПЕХ: P%d публично унижен (сбрасывает карту обмена)' % target['seat'])
            target['obmen'] = None
    def fail():
        cc = closed_cards(p)
        if cc:
            k, c = rng.choice(cc); p['hand'][k].remove(c); p['revealed'].append((k, c))
            log(f'    ПРОВАЛ (обратный эффект): осмеянным остался P{p["seat"]} — раскрывает [{k}]')
        else:
            log(f'    ПРОВАЛ: P{p["seat"]} опозорился, стол смеётся (без механики)')
    table_B(p, d20(), f'унижение P{target["seat"]}', succ, fail)

def rpds_world(p):
    if DRAW['ИНВЕНТАРЬ']:
        item = DRAW['ИНВЕНТАРЬ'].pop()
        def succ():
            p['hand'].setdefault('ИНВЕНТАРЬ', []).append(item)
            log(f'    УСПЕХ: найдено в мире → в руку [ИНВЕНТАРЬ]')
        def fail(): log('    ПРОВАЛ: мир не дал ничего (обратный эффект — narrativный)')
        table_V(p, d20(), 'РПДС: обыск мира', succ, fail)

def rpds_heal_self(p):
    def succ():
        p['or_'] = max(0, p['or_'] - 1); p['heal_taken'] += 1
        log(f'    УСПЕХ самолечения: −1 ОР → {p["or_"]}')
    def fail():
        log('    ПРОВАЛ самолечения: стало только хуже')
        p['heal_taken'] += 1; wound(p, 1, 'self')
    table_V(p, d20(), 'РПДС: самолечение', succ, fail)

def use_obmen(p, rpds_left, rpdi_left):
    if not p['obmen'] or rpds_left + rpdi_left == 0: return rpds_left, rpdi_left
    name, txt = p['obmen']
    use = False
    if name == 'Парамедик' and p['or_'] >= 1 and heal_ok(p): use = rng.random() < 0.8
    elif name == 'Отмена' and STATE['last_wound'] and STATE['last_wound'][0] == p['seat'] and p['or_'] >= 1: use = rng.random() < 0.75
    elif name == 'Взятка': use = False
    elif name in ('Заначка', 'Обмен', 'Второе дыхание', 'Свидетель', 'Подстава'): use = rng.random() < 0.45
    if not use: return rpds_left, rpdi_left
    log(f'    🃏 P{p["seat"]} тратит неиспользованное РПД: карта обмена «{name}»')
    if name == 'Парамедик':
        p['or_'] = max(0, p['or_'] - 1); p['heal_taken'] += 1
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Отмена':
        seat, amt = STATE['last_wound']; q = by_seat(seat)
        q['or_'] = max(0, q['or_'] - amt); STATE['last_wound'] = None
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Заначка':
        for _ in range(2):
            k = rng.choice(list(DRAW.keys()))
            if DRAW[k]: p['hand'].setdefault(k, []).append(DRAW[k].pop())
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Обмен':
        t = pick_target(p)
        if t is None:
            p['obmen'] = None
            return rpds_left, rpdi_left
        cc1, cc2 = closed_cards(p), closed_cards(t)
        if cc1 and cc2:
            k1, c1 = rng.choice(cc1); k2, c2 = rng.choice(cc2)
            p['hand'][k1].remove(c1); t['hand'][k2].remove(c2)
            p['hand'].setdefault(k2, []).append(c2); t['hand'].setdefault(k1, []).append(c1)
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Свидетель':
        t = pick_target(p)
        if t is None:
            p['obmen'] = None
            return rpds_left, rpdi_left
        cc = closed_cards(t)
        if cc:
            k, c = rng.choice(cc); t['hand'][k].remove(c); t['revealed'].append((k, c))
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Второе дыхание':
        rpds_left += 1
        if rpdi_left: rpdi_left -= 1
    elif name == 'Подстава':
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    p['obmen'] = None
    return rpds_left, rpdi_left

def ghost_use_card(g):
    if g['ghostcard'] is None: return
    tag, text = g['ghostcard']
    if tag in g['ghost_used'] and tag in ('cancel', 'eyes', 'fake', 'voice', 'photo'): return
    living = alive_list()
    if not living: return
    log(f'  👻 P{g["seat"]} применяет карту мёртвых: «{text.split("—")[0].strip()}…»')
    g['ghost_used'].add(tag)
    if tag == 'knock':
        for q in living: q['no_rpds'] = True
    elif tag == 'cold':
        rng.choice(living)['no_rpds'] = True
    elif tag == 'name':
        q = max(living, key=lambda x: x['or_']); q['no_target'] = True
    elif tag == 'cancel':
        if STATE['last_wound']:
            seat, amt = STATE['last_wound']; q = by_seat(seat)
            q['or_'] = max(0, q['or_'] - amt); STATE['last_wound'] = None
    elif tag == 'buff':
        rng.choice(living)['buff'] = 1
    elif tag == 'mirror':
        q = rng.choice(living); cc = closed_cards(q)
        if cc:
            k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
    elif tag == 'eyes':
        rng.choice(living)['skip_reveal'] = True
    elif tag == 'dark':
        STATE['dark'] = True
    elif tag == 'fake':
        q = rng.choice(living)
        if DRAW['ИНВЕНТАРЬ']: q['hand'].setdefault('ИНВЕНТАРЬ', []).append(DRAW['ИНВЕНТАРЬ'].pop())
    elif tag == 'voice':
        q = rng.choice(living); cc = closed_cards(q)
        if q['obmen']: q['obmen'] = None
        elif cc:
            k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
    elif tag == 'pain':
        hurt = [q for q in living if q['or_'] >= 1 and q['heal_taken'] < 1]
        if hurt:
            q = max(hurt, key=lambda x: x['or_']); q['or_'] -= 1; q['heal_taken'] += 1
    elif tag == 'photo':
        for q in living:
            cc = closed_cards(q)
            if cc:
                k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
    elif tag == 'queue':
        STATE['queue_shift'] = True
    g['ghostcard'] = None

def ghost_bets():
    for g in ghosts():
        if g['tokens'] >= 1 and rng.random() < 0.85:
            if len(alive_list()) >= 6: k = rng.choices([0, 1, 2], weights=[1, 5, 2])[0]
            else: k = rng.choices([1, 2, 3], weights=[2, 4, 2])[0]
            stake = 1 if g['tokens'] < 3 else rng.choice([1, 2])
            stake = min(stake, g['tokens']); g['tokens'] -= stake
            g['bet'] = (stake, k)
            log(f'  👻 ставка P{g["seat"]}: {stake} жет. на ровно {k} смертей')
        else: g['bet'] = None

def resolve_bets(cd):
    for g in ghosts():
        if g['bet']:
            stake, k = g['bet']
            if k == cd:
                g['tokens'] += stake * 2; STATE['bet_hits'] += 1
                log(f'  👻 СТАВКА СЫГРАЛА: P{g["seat"]} угадал {k} смертей → +{stake*2} жет.')
            g['bet'] = None

def ghost_shop(g):
    if g['tokens'] >= 3 and rng.random() < 0.4:
        g['tokens'] -= 1
        log(f'  👻 магазин мёртвых: P{g["seat"]} за 1 жет. подсматривает карты живого')
    if g['tokens'] >= 2 and rng.random() < 0.25:
        g['tokens'] -= 2
        q = rng.choice(alive_list()); cc = closed_cards(q)
        if cc:
            k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
            log(f'  👻 магазин мёртвых: P{g["seat"]} за 2 жет. принудительно раскрывает карту P{q["seat"]}')

def try_token_revive():
    gs = [g for g in ghosts() if g['died_cycle'] is not None and STATE['cycle'] - g['died_cycle'] >= 1]
    if not gs: return
    total = sum(g['tokens'] for g in gs)
    price = 5 if MODS.get('revive5') else 6
    medik = any(p['alive'] and p['prof'][0] == 'Медик' for p in P)
    if total >= price and (medik or rng.random() < 0.5):
        gs.sort(key=lambda g: (g['died_cycle'], g['seat']))
        r = gs[0]
        for g in gs: g['tokens'] = 0
        r['alive'] = True; r['or_'] = 0; r['tokens'] = 0; r['resurrected'] = True; r['heal_taken'] = 0
        STATE['token_revive'] = True
        log(f'  ✝️ ВОСКРЕШЕНИЕ: призраки скидывают жетоны общаком ({total}) — P{r["seat"]} возвращается с 0 ОР')

def mass_action(p):
    if VARIANT == 'amkary':
        cands = [q for q in alive_list() if q is not p and q['team'] != p['team'] and not q['no_target']]
        if len(cands) < 2: cands = [q for q in alive_list() if q is not p and not q['no_target']]
    else:
        cands = [q for q in alive_list() if q is not p and not q['no_target']]
    if len(cands) < 2: return False
    targets = rng.sample(cands, 2)
    thr = 15 if MODS.get('mass_low') else 18
    log(f'  P{p["seat"]}: МАССОВОЕ РПДИ (РАНЕНИЕ) против P{targets[0]["seat"]} и P{targets[1]["seat"]} — порог {thr}–20')
    nat = d20(); eff = mod_roll(p, nat, 'mass')
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [порог {thr}]')
    if eff >= thr:
        for t in targets: wound(t, 1, p['name'])
        log('    УСПЕХ массовки: каждой цели +1 ОР')
    else:
        log('    ПРОВАЛ массовки: обратный эффект — атакующему +2 ОР')
        wound(p, 2, 'self')
    STATE['mass_count'] += 1
    return True

def spec_bits(p, c, rpdi_left):
    if p['spec_used']: return rpdi_left
    tag, text = p['spec']
    def act():
        p['spec_used'] = True
        log(f'  ⚡ СПЕЦКАРТА: P{p["seat"]} активирует «{text}»')
    if tag == 'additem' and c == 2:
        act()
        if DRAW['ИНВЕНТАРЬ']: p['hand'].setdefault('ИНВЕНТАРЬ', []).append(DRAW['ИНВЕНТАРЬ'].pop())
    elif tag == 'extra' and c == 3:
        act(); rpdi_left += 1
    elif tag == 'immune' and c == 3 and rng.random() < 0.8:
        act(); p['immune'] = c
    elif tag == 'lootdead' and c >= 3 and ghosts():
        g = rng.choice(ghosts()); cc = closed_cards(g)
        if cc:
            act()
            k, card = rng.choice(cc); g['hand'][k].remove(card)
            p['hand'].setdefault(k, []).append(card)
    elif tag == 'fullheal' and c == 4:
        hurt = [q for q in alive_list() if q['or_'] >= 1]
        if hurt:
            q = max(hurt, key=lambda x: x['or_']); act(); q['or_'] = 0
    elif tag == 'avoid' and c == 4:
        act(); p['spec_armed'] = True
    elif tag == 'revive' and c >= 5 and ghosts() and not STATE['spec_revive']:
        gs = sorted(ghosts(), key=lambda g: (g['died_cycle'] or 99))
        act(); r = gs[0]
        r['alive'] = True; r['or_'] = 0; r['debuff'] = True; r['resurrected'] = True
        STATE['spec_revive'] = True
    elif tag == 'autohit' and c >= 5:
        t = max(alive_list(), key=lambda x: (x['or_'], rng.random()))
        if t is p: t = pick_target(p) or t
        if t is not p:
            act()
            log(f'    заявлено УБИЙСТВО P{t["seat"]} со 100% вероятностью (бросок не нужен)')
            wound(t, 2, p['name'])
    return rpdi_left

def choose_rpdi(p, c):
    gs = ghosts()
    if c == 1: opts, wts = ['humiliate','wound','steal','skip','heal'], [35,25,15,20,5]
    elif c == 2: opts, wts = ['wound','kill','steal','humiliate','heal','skip'], [30,25,12,13,10,10]
    elif c == 3: opts, wts = ['wound','kill','steal','humiliate','heal','skip','marauder'], [18,6,12,14,12,28,10 if gs else 0]
    elif c == 4: opts, wts = ['wound','kill','steal','humiliate','heal','skip','marauder','mass'], [24,16,10,10,10,15,10 if gs else 0,10]
    else: opts, wts = ['wound','kill','steal','humiliate','heal','skip','marauder'], [26,30,8,6,8,10,12 if gs else 0]
    if p['prof'][0] == 'Вор' and p['thief_left'] > 0 and c >= 2 and 'steal' in opts:
        wts[opts.index('steal')] += 15
    if p['prof'][0] == 'Медик' and 'heal' in opts: wts[opts.index('heal')] += 8
    if not [q for q in alive_list() if q is not p and q['or_'] >= 1 and heal_ok(q)] and 'heal' in opts:
        wts[opts.index('heal')] = 0
    return rng.choices(opts, weights=wts)[0]

def turn(p, c):
    log(f'  ——— P{p["seat"]} ({p["prof"][0]}), ОР={p["or_"]} ———')
    rev, rpds_left, rpdi_left = sched(c)
    if MODS.get('rpds_off'): rpds_left = 0
    rpdi_left += MODS.get('rpdi_extra', 0)
    if p['debuff']: rpdi_left = max(0, rpdi_left - 1)
    for i in range(rev): reveal(p)
    if p['no_rpds']:
        rpds_left = 0; p['no_rpds'] = False
    if rpds_left > 0:
        if p['or_'] >= 1 and (c > 1 or p['or_'] == 1) and rng.random() < 0.55:
            log('    РПДС: самолечение'); rpds_heal_self(p); rpds_left -= 1
        elif p['prof'][0] == 'Стример' and rng.random() < 0.6:
            log('    РПДС + «Стример»: стрим с донатами')
            def succ():
                if DRAW['ИНВЕНТАРЬ']: p['hand'].setdefault('ИНВЕНТАРЬ', []).append(DRAW['ИНВЕНТАРЬ'].pop())
            def fail(): log('    ПРОВАЛ: стрим забанили (обратный эффект — narrativный)')
            table_V(p, d20(), 'стрим', succ, fail); rpds_left -= 1
        elif rng.random() < 0.75:
            log('    РПДС: взаимодействие с миром'); rpds_world(p); rpds_left -= 1
    rpdi_left = spec_bits(p, c, rpdi_left)
    while rpdi_left > 0:
        before = rpdi_left
        act = choose_rpdi(p, c)
        if act == 'skip':
            log('    РПДИ сэкономлено — карта обмена наготове')
        elif act == 'mass':
            if not mass_action(p): log('    массовое действие не прошло по целям')
        elif act == 'marauder':
            g = rng.choice(ghosts()); cc = closed_cards(g)
            log(f'    РПДИ-мародёрство: тянет вслепую с трупа P{g["seat"]}')
            if cc:
                def succ():
                    k, card = rng.choice(closed_cards(g)); g['hand'][k].remove(card)
                    p['hand'].setdefault(k, []).append(card)
                def fail(): log('    ПРОВАЛ: труп не отдаёт карту (обратный эффект — по вкусу стола)')
                table_B(p, d20(), 'мародёрство', succ, fail)
            else: log('    на трупе пусто')
        elif act == 'wound':
            t = pick_target(p, need_dmg=True); t = cascade_check(p, t)
            if t is None: pass
            else:
                log(f'    РПДИ: заявлено РАНЕНИЕ P{t["seat"]}'); table_A(p, d20(), 'РАНЕНИЕ', t)
        elif act == 'kill':
            t = pick_target(p); t = cascade_check(p, t)
            if t is None: pass
            else:
                log(f'    РПДИ: заявлено УБИЙСТВО P{t["seat"]}'); table_A(p, d20(), 'УБИЙСТВО', t)
        elif act == 'steal':
            t = pick_target(p)
            if t is None: pass
            else:
                use_prof = p['prof'][0] == 'Вор' and p['thief_left'] > 0
                if use_prof: p['thief_left'] -= 1
                log(f'    РПДИ: кража у P{t["seat"]}' + (' (профессия «Вор»)' if use_prof else '') + ' вслепую')
                do_steal(p, t, use_prof=use_prof)
        elif act == 'heal':
            t = max([q for q in alive_list() if q is not p and q['or_'] >= 1 and heal_ok(q)], key=lambda x: x['or_'], default=None)
            if t is None: pass
            else:
                log(f'    РПДИ: помощь/лечение P{t["seat"]}'); do_heal_action(p, t)
        elif act == 'humiliate':
            t = pick_target(p); t = cascade_check(p, t)
            if t is None: pass
            else:
                log(f'    РПДИ: унижение P{t["seat"]}'); do_humiliate(p, t)
        if rpdi_left == before: rpdi_left -= 1
        else: rpdi_left -= 1
    rpds_left, rpdi_left = use_obmen(p, rpds_left, rpdi_left)

def rotate_hands():
    seats = sorted(P, key=lambda x: x['seat'])
    hands = [dict(pl['hand']) for pl in seats]
    for i, pl in enumerate(seats):
        pl['hand'] = hands[i - 1]
    STATE['rotations'] += 1
    log('  🔄 КОНЕЦ ЦИКЛА: все закрытые карты характеристик сдвигаются по кругу (эффект ситуации)')

def run_cycle(c):
    STATE['cycle'] = c
    STATE['player_death'] = False; STATE['dark'] = False
    STATE['last_wound'] = None; STATE['queue_shift'] = None
    deaths_before = STATE['deaths']
    log(f'════ ЦИКЛ {c} ════ живых {len(alive_list())}, призраков {len(ghosts())}')
    for g in ghosts():
        g['tokens'] += 2 if MODS.get('tokens2') else 1
        if DRAW_TENY and not MODS.get('teny_off'):
            g['ghostcard'] = DRAW_TENY.pop()
            log(f'  👻 P{g["seat"]}: +1 жетон (итого {g["tokens"]}), карта мёртвых «{g["ghostcard"][1].split("—")[0].strip()}…»')
        else:
            log(f'  👻 P{g["seat"]}: +1 жетон (итого {g["tokens"]})')
    if not MODS.get('bets_off'): ghost_bets()
    for g in ghosts():
        ghost_shop(g)
        if not MODS.get('teny_off'): ghost_use_card(g)
    if c >= 2 and not MODS.get('obmen_off'):
        for p in alive_list():
            p['obmen'] = rng.choice(G.OBMEN)
    if c >= 4: try_token_revive()
    for p in P: p['heal_taken'] = 0; p['no_target'] = False
    order = alive_list()
    if STATE['queue_shift'] and len(order) > 1:
        order = order[1:] + [order[0]]
    for p in order:
        if p['alive']: turn(p, c)
    log(f'  Конец цикла {c}: обмен и карты мёртвых — в сброс')
    cd = STATE['deaths'] - deaths_before
    resolve_bets(cd)
    if VARIANT == 'pole' and 2 <= c <= 4 and alive_list():
        v = rng.choice(alive_list())
        log(f'  ⚡ ПОЛЕ СУЖАЕТСЯ: P{v["seat"]} попадает в кромку — +1 ОР')
        before = STATE['deaths']
        wound(v, 1, 'поле')
        if STATE['deaths'] > before:
            STATE['field_deaths'] += 1
            cd += 1
    if VARIANT == 'hrono' and c in (2, 3, 4):
        rotate_hands()
    if c >= 2 and not STATE['player_death'] and not MODS.get('harvest_off') and len(alive_list()) >= 2:
        k = min(MODS.get('harvest_k', 1), len(alive_list()))
        STATE['harvests'] += 1
        for v in rng.sample(sorted(alive_list(), key=lambda x: x['seat']), k):
            log(f'  🌾 ЖАТВА: за цикл никто не умер от действий игроков — случайная смерть: P{v["seat"]}')
            check_death(v, 'жатва', 'Жатва')
            cd += 1
    if VARIANT in FORCED_END and c >= 5 and STATE['end_cycle'] is None:
        s = send()
        over = len(alive_list()) - s
        if over > 0:
            log(f'  🎲 ФИНАЛ СИТУАЦИИ: рандомный выбор убийства оставшихся — погибнет {over}')
            for v in rng.sample(alive_list(), over):
                check_death(v, 'финал', 'ситуация')
            STATE['forced'] = True
    if VARIANT in ('amkary', 'amkary2'):
        teams_alive = set(q['team'] for q in alive_list())
        if len(teams_alive) == 1 and len(alive_list()) >= 1:
            STATE['team_win'] = True
            STATE['end_cycle'] = c
            log(f'  🏁 Осталась одна команда — конец игры')
            return False
        if VARIANT == 'amkary2' and len(alive_list()) <= 1:
            STATE['end_cycle'] = c
            return False
        if VARIANT == 'amkary2':
            log(f'  (режим «на уничтожение»: порог S не проверяется, игра идёт до последней команды)')
            return True
    STATE['max_cycle_deaths'] = max(STATE['max_cycle_deaths'], cd)
    alive_n = len(alive_list())
    log(f'  Живых после цикла {c}: {alive_n} (порог конца {send()})')
    if alive_n <= send():
        STATE['end_cycle'] = c
        return False
    return True

def run_game(seed, n, variant, mods=None):
    LOG.clear()
    setup(seed, n, variant, mods)
    log(f'ПАРТИЯ «БЛИЦ БОЙ» — {n} игроков, seed={seed}, ситуация: {VNAME[variant]}')
    c = 1
    while c <= 12:
        if not run_cycle(c): break
        c += 1
    if STATE['end_cycle'] is None: STATE['end_cycle'] = c
    win = [p['seat'] for p in alive_list()]
    log(f'ИТОГ: игра окончена в цикле {STATE["end_cycle"]}. Победили места: {win}')
    return dict(n=n, variant=variant, seed=seed, end=STATE['end_cycle'], deaths=STATE['deaths'],
                roll_dist=dict(STATE['rolls']), max_cycle_deaths=STATE['max_cycle_deaths'],
                no_win=(len(win) == 0), stall=(STATE['end_cycle'] >= 12),
                alive=len(win), win=win, harvests=STATE['harvests'], token_revive=STATE['token_revive'],
                spec_revive=STATE['spec_revive'], avoid=STATE['avoid_saved'], bets_hit=STATE['bet_hits'],
                mass=STATE['mass_count'], nat1=STATE['nat1'], nat20=STATE['nat20'],
                first_death=STATE['first_death_cycle'], forced=STATE['forced'],
                team_win=STATE['team_win'], rotations=STATE['rotations'], field_deaths=STATE['field_deaths'],
                S=STATE['S'], W=STATE['W'])

def main():
    mods = None
    for a in sys.argv[1:]:
        if a.startswith('{'):
            mods = json.loads(a)
    st = run_game(SEED, N, VARIANT, mods)
    if not QUIET:
        print('\n'.join(LOG))
    print('STATS=' + json.dumps(st, ensure_ascii=False))

if __name__ == '__main__':
    main()
