# -*- coding: utf-8 -*-
"""sim8 — расширенный симулятор «БЛИЦ БОЙ» для 8-пунктного исследования.

Надстройка над sim/sim_n.py: ядро правил не тронуто, поэтому базовый режим
(без модификаторов) воспроизводит sim_n бит-в-бит при тех же сидах.

Добавлено:
  * обезличенный пул карт sim1000 (только ID, без названий)            — мод pool='sim1000'
  * расширенные каталоги механик: профессии / спецкарты / карты мёртвых — мод weird=True
  * 2-3 спецкарты на игрока                                             — моды spec2, spec3
  * 2-3 карты мёртвых за цикл                                           — мод teny_k
  * профили поведения игроков (12 типов)                                — мод profile / profiles
  * собирательство как отдельное РП-действие                            — мод collect
  * 10 новых ситуаций (fog timer bounty silent plague market arena conclave heirloom duel)
  * счётчики событий для модели реальной длительности партии (STATE['T'])

Usage: python3 sim/sim8.py SEED N [VARIANT] [--quiet] ['{"мод":значение}']
В конце партии печатается STATS={json}.
"""
import json, random, sys, math, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import game_sim as G   # берём только данные: POOLS, SPECS, TENY, OBMEN

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 1
N = int(sys.argv[2]) if len(sys.argv) > 2 else 8
VARIANT = sys.argv[3] if len(sys.argv) > 3 and not sys.argv[3].startswith('--') else 'base'
QUIET = '--quiet' in sys.argv

LOG = []
def log(s): LOG.append(s)

# =====================================================================
#  КАТАЛОГИ МЕХАНИК (обезличенные). В отчётах карты и способности
#  фигурируют только по кодам механик: имена и художественный текст
#  намеренно не публикуются и в логи не попадают.
# =====================================================================

def T(k, v=1):
    """Счётчик событий партии (для модели времени). Случайных чисел не расходует."""
    STATE['T'][k] = STATE['T'].get(k, 0) + v

# --- новые активные профессии: (код, описание механики, тег) ---
PROF_X = [
 ('PRX-01', 'раз в игру забирает профессию другого игрока до конца партии', 'stealprof'),
 ('PRX-02', 'раз в цикл меняет порядок хода (сдвиг очереди)', 'order'),
 ('PRX-03', 'раз в цикл блокирует чужую спецкарту до конца цикла', 'speclock'),
 ('PRX-04', 'раз в цикл возвращает 1 ОР источнику урона', 'reflect'),
 ('PRX-05', 'раз в цикл берёт карту из колоды (собирательство)', 'drawcard'),
 ('PRX-06', 'копирует механику одной чужой спецкарты', 'copyspec'),
 ('PRX-07', 'раз в цикл забирает карту у игрока, не потратившего РП-действие', 'idletax'),
 ('PRX-08', 'раз в цикл принудительно меняет раскрытые карты двух игроков', 'forceswap'),
 ('PRX-09', 'раз в игру отменяет одно заявленное РП-действие до броска', 'veto'),
 ('PRX-10', 'поражение цели без крит-провала, но только по цели с 2+ ОР', 'safekill'),
 ('PRX-11', 'лечит без лимита за цикл, но провал даёт автору +1 ОР', 'healunlock'),
 ('PRX-12', 'с 3-го цикла получает +1 РПДИ (знает расписание наперёд)', 'extralate'),
 ('PRX-13', 'постоянный +1 к собственным броскам', 'luck2'),
 ('PRX-14', 'считается своим для обеих команд в командных ситуациях', 'teamboth'),
]
# профессии-«декорации»: роль за столом без отдельной механики
PROF_X_PASSIVE = [('PRX-%02d' % i, '', 'none') for i in range(15, 25)]

# --- новые спецкарты: (тег, описание механики) ---
SPEC_X = [
 ('swap_hands',  'обмен всеми закрытыми картами с любым игроком'),
 ('ghost_cycle', 'на один цикл становишься призраком: не цель, не действуешь, +2 жетона'),
 ('steal_prof',  'забираешь профессию другого игрока до конца партии'),
 ('chaos_swap',  'все живые сдвигают закрытые руки по кругу'),
 ('reflect',     'весь урон этого цикла возвращается источникам'),
 ('duplicate',   'повторяешь своё последнее РП-действие ещё раз в этом цикле'),
 ('veto',        'отменяешь одно заявленное РП-действие до броска'),
 ('reveal_all',  'все живые раскрывают по две карты'),
 ('debt',        'выбранный игрок теряет по одному РПДИ в двух следующих циклах'),
 ('shield_ally', 'выбранный игрок невосприимчив к урону два цикла'),
 ('transfer',    'переносишь все свои ОР на другого игрока'),
 ('second_life', 'после гибели сразу возвращаешься с 1 ОР (срабатывает один раз)'),
 ('bounty',      'назначаешь цель: кто её ранит, тянет карту'),
 ('time_lock',   'в этом цикле никто не заявляет поражение цели, только ранения'),
 ('hoard_bonus', 'тянешь три карты из колоды (чистое собирательство)'),
 ('double_turn', 'в этом цикле у тебя вдвое больше РПДИ'),
]

# --- новые карты мёртвых: (тег, описание механики) ---
TENY_X = [
 ('mass_reveal',  'все живые раскрывают по одной карте'),
 ('token_tax',    'забираешь по одному жетону у каждого другого призрака'),
 ('curse',        'выбранный живый получает −2 к броскам до конца цикла'),
 ('swap_or',      'меняет местами ОР двух живых игроков'),
 ('fake_death',   'живой до конца цикла считается выбывшим: не цель и не действует'),
 ('silence',      'в этом цикле никто не применяет карты обмена'),
 ('harvest_x2',   'Жатва в этом цикле бьёт по двум игрокам'),
 ('ghost_king',   '+3 жетона и право вето на одно воскрешение'),
 ('hand_lock',    'живой не может тратить РПДИ на кражу в этом цикле'),
 ('reroll_bad',   'перебрасывает бросок живого и ухудшает результат на 2'),
]

# --- профили поведения игроков (типы за столом) ---
# w — поправки к весам выбора РПДИ; *_p — вероятность применения механик;
# think/narrate/chatter/dispute — множители времени для модели длительности
PROFILES = {
 'aggr':    dict(label='Агрессор',     w=dict(kill=18, wound=10, heal=-8, humiliate=-4, skip=-10),
                 think=0.8, narrate=1.1, chatter=0.9, dispute=1.3, spec_p=0.90, prof_p=0.90, obmen_p=1.0, target='weak'),
 'hoard':   dict(label='Собиратель',   w=dict(steal=20, skip=8, kill=-18, wound=-8, humiliate=-6, heal=4, collect=16),
                 think=1.1, narrate=0.9, chatter=0.7, dispute=0.8, spec_p=0.70, prof_p=0.80, obmen_p=1.1, target='any', hoard=True),
 'actor':   dict(label='Актёр',        w=dict(humiliate=20, mass=6, kill=-8, steal=2, skip=-6),
                 think=1.0, narrate=1.5, chatter=1.6, dispute=1.2, spec_p=0.80, prof_p=0.90, obmen_p=1.0, target='any'),
 'manip':   dict(label='Манипулятор',  w=dict(steal=12, humiliate=10, kill=4, heal=-4, skip=-4),
                 think=1.3, narrate=1.1, chatter=1.3, dispute=1.4, spec_p=0.95, prof_p=0.95, obmen_p=1.3, target='any'),
 'team':    dict(label='Командник',    w=dict(heal=14, mass=10, wound=6, kill=4, humiliate=-6, steal=-6),
                 think=1.0, narrate=1.0, chatter=1.4, dispute=1.0, spec_p=0.85, prof_p=0.90, obmen_p=1.0, target='enemy'),
 'turtle':  dict(label='Выживальщик',  w=dict(skip=18, heal=12, kill=-14, wound=-10, humiliate=-8, mass=-8),
                 think=1.2, narrate=0.8, chatter=0.6, dispute=0.7, spec_p=0.90, prof_p=0.60, obmen_p=1.2, target='any'),
 'gambler': dict(label='Азартный',     w=dict(kill=10, mass=14, wound=4, heal=-6, skip=-8),
                 think=0.7, narrate=1.0, chatter=1.2, dispute=1.1, spec_p=0.85, prof_p=0.85, obmen_p=1.0, target='random', bet=True),
 'chaos':   dict(label='Хаотик',       w=dict(mass=10, humiliate=10, steal=8, kill=6, heal=-10, skip=-10),
                 think=0.6, narrate=1.2, chatter=1.8, dispute=1.6, spec_p=0.95, prof_p=0.95, obmen_p=1.2, target='random'),
 'medic':   dict(label='Спасатель',    w=dict(heal=26, kill=-20, wound=-10, humiliate=-6, skip=4),
                 think=1.0, narrate=0.9, chatter=0.9, dispute=0.6, spec_p=0.90, prof_p=0.80, obmen_p=1.1, target='ally'),
 'marauder':dict(label='Мародёр',      w=dict(marauder=20, steal=10, kill=6, heal=-8, skip=-6),
                 think=0.9, narrate=0.9, chatter=0.8, dispute=1.0, spec_p=0.85, prof_p=0.90, obmen_p=1.0, target='dead'),
 'star':    dict(label='Звезда стола', w=dict(humiliate=12, mass=8, kill=2, heal=-4),
                 think=1.1, narrate=1.9, chatter=2.2, dispute=1.5, spec_p=0.90, prof_p=1.00, obmen_p=1.1, target='any'),
 'lurker':  dict(label='Молчун',       w=dict(skip=14, wound=2, kill=-6, humiliate=-10, mass=-6),
                 think=0.5, narrate=0.4, chatter=0.2, dispute=0.3, spec_p=0.50, prof_p=0.40, obmen_p=0.7, target='any'),
 'neutral': dict(label='Нейтральный',  w=dict(),
                 think=1.0, narrate=1.0, chatter=1.0, dispute=1.0, spec_p=0.80, prof_p=0.75, obmen_p=1.0, target='any'),
}

# пресеты стола: какие типы доминируют в каком режиме (пункт 7 исследования)
PRESETS = {
 'party':    ['actor','actor','chaos','star','gambler','lurker','manip','actor'],
 'meat':     ['aggr','aggr','gambler','manip','aggr','chaos','aggr','gambler'],
 'coop':     ['team','medic','turtle','team','medic','team','turtle','medic'],
 'intrigue': ['manip','marauder','team','turtle','manip','lurker','actor','manip'],
 'survive':  ['hoard','turtle','marauder','medic','hoard','turtle','hoard','medic'],
 'newbie':   ['lurker','medic','actor','turtle','lurker','actor','turtle','medic'],
 'maxweird': ['chaos','star','manip','chaos','gambler','actor','manip','star'],
 'mixed':    ['aggr','hoard','actor','manip','team','turtle','gambler','chaos',
             'medic','marauder','star','lurker'],
}

# вероятность того, что событие выливается в спор о правилах.
# Споры считаются как математическое ожидание (событие × вероятность),
# без дополнительных бросков — иначе сломалась бы воспроизводимость партии.
DISPUTE_P = {
 'crit_fail_kill': 0.75, 'crit_kill': 0.55, 'avoid_death': 0.85, 'cascade': 0.70,
 'veto': 0.80, 'cancel': 0.70, 'mass_fail': 0.45, 'steal_fail': 0.40,
 'humiliate_fail': 0.35, 'forced_reveal': 0.30, 'harvest': 0.35, 'revive': 0.60,
 'weird': 0.50, 'spec': 0.35, 'ghost': 0.25, 'immunity': 0.45, 'reflect': 0.60,
 'swap': 0.40, 'prof': 0.25, 'death': 0.30, 'vote': 0.45, 'bounty': 0.30,
}
def dispute(kind):
    """Ожидание спора (без доп. бросков); вес — по профилю текущего актёра."""
    m = 1.0
    cur = STATE.get('cur')
    if isinstance(cur, dict): m = cur.get('pr', {}).get('dispute', 1.0)
    T('disputes_e', DISPUTE_P.get(kind, 0.3) * m)

def prof_tag(p):
    pr = p['prof']
    return pr[2] if len(pr) > 2 else ''

PROF_ACTIVE = G_PROFS = [
 ('Почтальон','получает в инвентарь посылку с рандомным предметом'),
 ('Стример','может вести стрим и собирать донаты'),
 ('Водитель','получает любую машину на выбор'),
 ('Вор','может украсть одну вещь за цикл, работает 3 раза'),
 ('Медик','может воскресить другого игрока'),
 ('Крупье','может перебросить кубик 1 раз за цикл'),
 ('Шизик','немного поехавший, но везучий'),
 ('Каскадёр','принимает на себя РП действие, направленное на другого (до броска)'),
]
PROF_PASSIVE = [
 ('Сантехник',''), ('Бухгалтер',''), ('Охранник',''), ('Повар',''),
 ('Таксист',''), ('Грузчик',''), ('Сварщик',''), ('Рыбак',''),
 ('Дворник',''), ('Продавец',''), ('Курьер',''), ('Плотник',''),
]
PROF_ALL = PROF_ACTIVE + PROF_PASSIVE

# расписания ситуаций: cycle -> (раскрытий, РПДС, РПДИ); forced = «рандомный выбор убийства» в конце 5-го цикла
SCHED = {
 'base':   {1:(2,1,1), 2:(1,1,1)},
 # --- новые ситуации исследования (пункт 5): (раскрытий, РПДС, РПДИ) ---
 'fog':     {1:(0,2,1), 2:(0,1,1)},
 'timer':   {1:(2,1,1), 2:(1,1,1), 3:(1,1,1), 4:(1,0,1), 5:(1,0,1), 6:(0,0,1)},
 'bounty':  {1:(2,1,1), 2:(1,1,1)},
 'silent':  {1:(2,1,1), 2:(1,1,1)},
 'plague':  {1:(2,1,1), 2:(1,1,1)},
 'market':  {1:(1,2,1), 2:(1,1,1)},
 'arena':   {1:(1,0,2), 2:(1,0,2)},
 'conclave':{1:(2,1,1), 2:(1,1,1)},
 'heirloom':{1:(2,1,1), 2:(1,1,1)},
 'duel':    {1:(2,1,1), 2:(1,1,1)},
 'plane':  {1:(1,1,0), 2:(2,1,1), 3:(3,1,1), 4:(0,0,1), 5:(1,0,1)},
 'tomato': {1:(2,1,0), 2:(1,1,1), 3:(2,1,1), 4:(0,0,1), 5:(1,1,1)},
 'pole':   {1:(3,1,0), 2:(2,1,1), 3:(1,1,1), 4:(0,0,1), 5:(1,1,1)},
 'purg':   {1:(3,0,1), 2:(1,1,1), 3:(1,1,2), 4:(0,0,1), 5:(1,1,1)},
 'amkary': {1:(2,1,0), 2:(2,1,1), 3:(2,1,1), 4:(0,0,1), 5:(1,1,1)},
 'amkary2':{1:(2,1,0), 2:(2,1,1), 3:(2,1,1), 4:(0,0,1), 5:(1,1,1)},
 'hrono':  {1:(2,0,2), 2:(1,1,1), 3:(1,1,1), 4:(2,1,2), 5:(1,1,2)},
}
FORCED_END = {'plane','tomato','pole','purg','amkary','timer'}
VNAME = {'base':'«Ночь в панельке» (базовое расписание)','plane':'«Самолёт в Гренландию»',
         'tomato':'«Помидор, забывший тройку»','pole':'«Поле на остановке»',
         'purg':'«Чистилище»','amkary':'«Амкары и Касторама»','hrono':'«Пьяная хронология»',
         'amkary2':'«Амкары: режим на уничтожение»',
         # --- новые режимы исследования ---
         'fog':'режим FOG — информационный голод (раскрытий нет)',
         'timer':'режим TIMER — порог конца падает каждый цикл',
         'bounty':'режим BOUNTY — каждый цикл объявляется заказ на цель',
         'silent':'режим SILENT — минимум слов, только механика',
         'plague':'режим PLAGUE — среда наносит урон каждый цикл',
         'market':'режим MARKET — жетоны у живых и торговля',
         'arena':'режим ARENA — только бой, без мира и лечения',
         'conclave':'режим CONCLAVE — общее голосование каждый цикл',
         'heirloom':'режим HEIRLOOM — наследство погибшего уходит убийце',
         'duel':'режим DUEL — парные столкновения каждый цикл'}
NEWVARS = {'fog','timer','bounty','silent','plague','market','arena','conclave','heirloom','duel'}
TEAMVARS = {'amkary','amkary2'}

def sched(c):
    s = SCHED[VARIANT]
    if c in s: return s[c]
    return s[max(k for k in s if k <= c)]

rng = None
P, DRAW, STATE = [], {}, {}
DRAW_TENY = []

MODS = {}

# обезличенный пул sim1000: {категория: [ID карты, ...]}
_POOL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pool_sim1000.json')
POOL1000 = None
POOL_CATS = ['ТЕЛО', 'РАЗУМ', 'СПОСОБНОСТИ', 'ИНВЕНТАРЬ', 'ИСТОРИЯ', 'ЗНАНИЯ', 'ДЕТАЛИ']

def pool1000():
    global POOL1000
    if POOL1000 is None:
        d = json.load(open(_POOL_PATH, encoding='utf-8'))
        POOL1000 = {k: [c['id'] for c in v['cards']] for k, v in d['categories'].items()}
    return POOL1000

# новые карты обмена (только для режима weird)
OBMEN_X = [
 ('Сделка',  'потрать неиспользованное РПД: обменяй две свои закрытые карты на одну карту любого игрока'),
 ('Сбор',    'потрать неиспользованное РПД: вытяни три карты из колоды'),
 ('Щит',     'потрать неиспользованное РПД: до конца цикла ты невосприимчив к чужому урону'),
 ('Перевод', 'потрать неиспользованное РПД: переведи 1 свой ОР на другого игрока'),
 ('Торг',    'потрать неиспользованное РПД: забери жетон у любого призрака'),
]
ACTIVE_SET = None

def setup(seed, n, variant, mods=None):
    global rng, P, DRAW, STATE, DRAW_TENY, VARIANT, N, MODS, ACTIVE_SET
    MODS = dict(mods or {})
    VARIANT, N = variant, n
    rng = random.Random(seed)
    weird = bool(MODS.get('weird'))

    # --- колода характеристик: legacy-пулы или обезличенный sim1000 ---
    if MODS.get('pool') == 'sim1000':
        src = pool1000()
        DRAW = {k: src[k][:] for k in POOL_CATS}
    else:
        DRAW = {k: v[:] for k, v in G.POOLS.items()}
    for k in DRAW: rng.shuffle(DRAW[k])

    DRAW_TENY = G.TENY[:] + (TENY_X if weird else [])
    rng.shuffle(DRAW_TENY)
    prof_pool = PROF_ALL[:] + ((PROF_X + PROF_X_PASSIVE) if weird else [])
    if MODS.get('prof_all'):                       # у всех — активная профессия
        prof_pool = PROF_ACTIVE[:] + (PROF_X if weird else [])
    rng.shuffle(prof_pool)
    spec_pool = G.SPECS[:] + (SPEC_X if weird else [])
    rng.shuffle(spec_pool)
    obmen_pool = G.OBMEN[:] + (OBMEN_X if weird else [])
    rng.shuffle(obmen_pool)
    if MODS.get('team_random'):
        TEAMVARS.add(variant)

    # --- профили поведения ---
    preset = MODS.get('preset')
    plist = MODS.get('profiles') or (PRESETS[preset] if preset in PRESETS else None)
    one = MODS.get('profile') or ('hoard' if MODS.get('hoard_bias') else 'neutral')

    nspec = 3 if MODS.get('spec3') else (2 if MODS.get('spec2') else 1)
    draft = int(MODS.get('draft', 1))
    dth = int(MODS.get('dth', 3))

    P = []
    for i in range(n):
        hand = {k: [DRAW[k].pop() for _ in range(draft)] for k in DRAW}
        pk = plist[i % len(plist)] if plist else one
        pr = PROFILES.get(pk, PROFILES['neutral'])
        myspecs = [spec_pool[(i * nspec + j) % len(spec_pool)] for j in range(nspec)]
        p = dict(seat=i+1, name=f'Игрок {i+1}', prof=prof_pool[i % len(prof_pool)], hand=hand,
                 revealed=[], alive=True, spec=myspecs[0], spec_used=False,
                 spec_armed=False, tokens=0, ghostcard=None, ghost_used=set(), bet=None,
                 obmen=obmen_pool[i % len(obmen_pool)], heal_taken=0, thief_left=3, croupier_used_cycle=0,
                 immune=0, no_rpds=False, no_target=False, skip_reveal=False, buff=0,
                 debuff=False, died_cycle=None, resurrected=False, kills=0, dark_pen=0,
                 team=(i % 2 if variant in TEAMVARS else -1), or_=0,
                 # ---------- расширения sim8 ----------
                 pkey=pk, pr=pr, specs=myspecs, spec_used_n=0, ghostcards=[],
                 second_life=any(t == 'second_life' for t, _ in myspecs),
                 debt=0, curse=0, frozen=False, gcycle=False, no_steal=False, spec_lock=False,
                 bounty_on=False, last_act=None, dup_ready=False,
                 prof_uses=0, spec_uses=0, collect_n=0, obmen_uses=0, wasted=0,
                 cards_gained=sum(len(v) for v in hand.values()), cards_lost=0,
                 veto_used=False, order_used=0, speclock_used=0, draw_used=0,
                 idletax_used=0, forceswap_used=0, reflect_used=0, stealprof_used=False,
                 healunlock=False, luck2=False, extralate=False, teamboth=False, safekill=False)
        P.append(p)
    if weird:
        for p in P:
            t = prof_tag(p)
            if t == 'luck2': p['luck2'] = True
            if t == 'extralate': p['extralate'] = True
            if t == 'teamboth': p['teamboth'] = True
    post = [p for p in P if p['prof'][0] == 'Почтальон']
    if post and DRAW['ИНВЕНТАРЬ']:
        post[0]['hand']['ИНВЕНТАРЬ'].append(DRAW['ИНВЕНТАРЬ'].pop())
        post[0]['cards_gained'] += 1
    if MODS.get('open_hands'):
        for p in P:
            for k, lst in p['hand'].items():
                for c in lst: p['revealed'].append((k, c))
            p['hand'] = {k: [] for k in p['hand']}
    S = math.floor(n / 2)
    if variant in ('tomato', 'pole') and n in (3, 4): S = 2
    if MODS.get('s_plus1'): S += 1
    if MODS.get('s_third'): S = max(1, math.floor(n / 3))
    if MODS.get('solo'): S = 1
    W = S
    if variant == 'purg':
        W = rng.randint(1, n)
        log(f'Мест в раю: бросок d{n} = {W}')
    STATE = dict(cycle=0, player_death=False, dark=False, last_wound=None, harvests=0,
                 bet_hits=0, token_revive=False, spec_revive=False, avoid_saved=False,
                 mass_count=0, nat1=False, nat20=False, first_death_cycle=None,
                 end_cycle=None, deaths=0, queue_shift=None, S=S, W=W, forced=False,
                 team_win=False, rotations=STATE.get('rotations', 0) if False else 0,
                 field_deaths=0, rolls={}, max_cycle_deaths=0, mods=dict(MODS),
                 # ---------- расширения sim8 ----------
                 T={}, dmg_log=[], S0=S, dth=dth, weird=weird, nspec=nspec,
                 bounty_seat=None, silence=False, no_kill=False, harvest_x2=False,
                 veto_pending=False, expel_seat=None, votes=0, duels=0, market_buys=0,
                 spec_uses=0, prof_uses=0, ghost_uses=0, obmen_uses=0, collect_total=0,
                 weird_events=0, reflects=0, second_lives=0, hoard_cards=0,
                 order_next=False, reflect_cycle=None, idle_seats=set(), cur=None,
                 plagues=0, expels=0, timer_ticks=0, vetoes=0, dups=0)

def by_seat(s): return P[s-1]
def alive_list(): return [p for p in P if p['alive']]
def ghosts(): return [p for p in P if not p['alive']]
def d20():
    r = rng.randint(1, 20)
    STATE['rolls'][r] = STATE['rolls'].get(r, 0) + 1
    if MODS.get('roll_best') or MODS.get('roll_worst'):
        r2 = rng.randint(1, 20)
        STATE['rolls'][r2] = STATE['rolls'].get(r2, 0) + 1
        T('rolls')
        r = max(r, r2) if MODS.get('roll_best') else min(r, r2)
    T('rolls')
    return r

def prof_use(p, kind):
    """Регистрация применения профессии + вероятность спора."""
    p['prof_uses'] += 1
    STATE['prof_uses'] += 1
    T('profs'); T('prof_' + kind, 1)
    dispute('prof')
def send(): return STATE['W'] if VARIANT == 'purg' else STATE['S']

def closed_cards(p):
    out = []
    for k, lst in p['hand'].items():
        for c in lst: out.append((k, c))
    return out

def reveal(p):
    if MODS.get('no_reveal'):
        return None
    if p['skip_reveal']:
        p['skip_reveal'] = False
        log(f'  P{p["seat"]}: раскрытие пропущено (Ладонь на глазах)')
        return None
    cc = closed_cards(p)
    if not cc: return None
    if STATE['cycle'] == 1 and not any(r[0] == 'ПРОФЕССИЯ' for r in p['revealed']):
        card = p['prof'][0] + (' - ' + p['prof'][1] if p['prof'][1] else '')
        p['revealed'].append(('ПРОФЕССИЯ', card))
        T('reveals')
        log(f'  P{p["seat"]} раскрывает [ПРОФЕССИЯ] {card}')
        return ('ПРОФЕССИЯ', card)
    k, c = rng.choice(cc)
    p['hand'][k].remove(c); p['revealed'].append((k, c))
    p['cards_lost'] += 1
    T('reveals')
    log(f'  P{p["seat"]} раскрывает [{k}] {c}')
    return (k, c)

def mod_roll(p, roll, kind):
    m = roll
    if p['buff'] and kind != 'mass':
        m += p['buff']; log(f'    (+{p["buff"]} от карты мёртвых «усиление»)'); p['buff'] = 0
    if p.get('curse', 0):
        m -= p['curse']
    if p.get('luck2'):
        m += 1
    if STATE['dark'] and kind in ('рпди', 'mass'):
        m -= 1; p['dark_pen'] += 1
    return m

def croupier_reroll(actor, roll, kind):
    crs = [p for p in P if p['prof'][0] == 'Крупье' and p['alive']]
    if not crs: return roll
    cr = crs[0]
    if cr is actor or cr['croupier_used_cycle'] == STATE['cycle'] or roll >= 10: return roll
    if rng.random() < 0.55:
        cr['croupier_used_cycle'] = STATE['cycle']
        r2 = d20()
        prof_use(cr, 'reroll')
        dispute('prof')
        log(f'    ПЕРЕБРОС: P{cr["seat"]} перебрасывает чужой кубик {roll} → {r2}')
        return r2
    return roll

def wound(p, amt, src=''):
    if MODS.get('escalation') and STATE['cycle'] >= 4 and src not in ('self', 'поле', 'среда'):
        amt += 1
    if p['immune'] >= STATE['cycle'] and src not in ('self', 'поле', 'среда'):
        log(f'    P{p["seat"]} НЕВОСПРИИМЧИВ: {amt} ОР не проходит')
        T('immunity'); dispute('immunity')
        return False
    p['or_'] += amt
    STATE['last_wound'] = (p['seat'], amt)
    T('wounds', amt)
    if src not in ('self', 'поле', 'среда', 'Жатва'):
        STATE['dmg_log'].append((p['seat'], amt, src))
        # спецкарта «reflect»: весь урон цикла возвращается источнику
        if STATE.get('reflect_cycle') == STATE['cycle']:
            tgt = next((q for q in P if q['name'] == src), None)
            if tgt is not None and tgt['alive'] and tgt is not p:
                STATE['reflects'] += 1
                T('wounds', amt); dispute('reflect')
                log(f'    ОТРАЖЕНИЕ (спецкарта): {amt} ОР возвращены источнику P{tgt["seat"]}')
                tgt['or_'] += amt
                if tgt['or_'] >= STATE['dth']: check_death(tgt, 'отражение', p['name'])
        # режим BOUNTY: ранивший заказанную цель тянет карту
        if VARIANT == 'bounty' and STATE.get('bounty_seat') == p['seat']:
            att = next((q for q in alive_list() if q['name'] == src), None)
            if att is not None and att is not p:
                draw_cards(att, 1, 'bounty'); T('bounty_hit'); dispute('bounty')
                log(f'    BOUNTY: P{att["seat"]} ранил заказанную цель и тянет карту')
        # механика PRX-04 «отражение»: раз в цикл возвращает 1 ОР источнику
        rf = [q for q in alive_list() if prof_tag(q) == 'reflect' and q['reflect_used'] != STATE['cycle']
              and q is not p and q['seat'] != p['seat']]
        if rf and MODS.get('weird'):
            r0 = rf[0]
            tgt = next((q for q in P if q['name'] == src), None)
            if tgt is not None and tgt['alive']:
                r0['reflect_used'] = STATE['cycle']
                STATE['reflects'] += 1
                log(f'    ОТРАЖЕНИЕ: P{r0["seat"]} возвращает 1 ОР источнику P{tgt["seat"]}')
                dispute('reflect')
                tgt['or_'] += 1
                T('wounds')
                if tgt['or_'] >= STATE['dth']: check_death(tgt, 'отражение', r0['name'])
    log(f'    P{p["seat"]}: +{amt} ОР → всего {p["or_"]}')
    if p['or_'] >= STATE['dth']: check_death(p, 'ранения', src)
    return True

def check_death(p, cause, src=''):
    if not p['alive']: return
    if p['spec_armed'] and cause != 'жатва':
        p['spec_armed'] = False; p['spec_used'] = True; p['spec_used_n'] += 1; p['or_'] = 2
        STATE['avoid_saved'] = True
        T('specs'); dispute('avoid_death')
        log(f'    !!! P{p["seat"]} уходит от смерти: спецкарта «избежать гибели», ОР сброшены до 2')
        return
    if p.get('second_life') and cause != 'жатва':
        p['second_life'] = False; p['or_'] = 1; p['debuff'] = True
        STATE['second_lives'] += 1
        T('specs'); dispute('spec'); T('discuss_e', 0.5)
        log(f'    !!! P{p["seat"]}: спецкарта «вторая жизнь» — возвращается с 1 ОР и −1 РПДИ')
        return
    p['alive'] = False; p['died_cycle'] = STATE['cycle']
    T('deaths'); dispute('death')
    if VARIANT == 'heirloom':
        killer = next((q for q in P if q['name'] == src and q['alive']), None)
        cc = closed_cards(p)
        if killer and cc:
            for k, c in cc:
                p['hand'][k].remove(c); killer['hand'].setdefault(k, []).append(c)
                killer['cards_gained'] += 1; p['cards_lost'] += 1
            T('weird'); dispute('weird')
            log(f'    НАСЛЕДСТВО: {len(cc)} закрытых карт P{p["seat"]} уходят P{killer["seat"]}')
    STATE['deaths'] += 1
    if STATE['first_death_cycle'] is None: STATE['first_death_cycle'] = STATE['cycle']
    if cause in ('жатва', 'поле', 'финал'):
        log(f'    💀 P{p["seat"]} УМИРАЕТ ({cause})')
    else:
        STATE['player_death'] = True
        log(f'    💀 P{p["seat"]} УМИРАЕТ ({cause}, источник: {src or "—"})')
    p['obmen'] = None

def table_A(p, roll, declared, target, kind='рпди'):
    nat = roll; eff = mod_roll(p, roll, kind)
    if nat == 20: STATE['nat20'] = True
    if nat == 1: STATE['nat1'] = True
    if nat == 1: eff = 1
    if nat == 20: eff = 20
    eff = croupier_reroll(p, eff, kind)
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [таблица А, {declared}]')
    T('table_a')
    if declared == 'УБИЙСТВО':
        if eff <= 4:
            log('    КРИТ-ПРОВАЛ: удар возвращается в автора'); T('crit_fail'); dispute('crit_fail_kill')
            check_death(p, 'крит-провал собственного поражения', p['name'])
        elif eff <= 8: wound(p, 1, 'свой провал')
        elif eff <= 12: log('    ничего не произошло')
        elif eff <= 16: wound(target, 2, p['name']); p['kills'] += 0
        else:
            log('    КРИТ: цель выбывает сразу'); p['kills'] += 1
            T('crit_kill'); dispute('crit_kill')
            check_death(target, 'крит поражения', p['name'])
    else:
        if eff <= 4: log('    КРИТ-ПРОВАЛ: +2 ОР автору'); T('crit_fail'); dispute('crit_fail_kill'); wound(p, 2, 'self')
        elif eff <= 8: wound(p, 1, 'self')
        elif eff <= 12: log('    ничего не произошло')
        elif eff <= 16: wound(target, 1, p['name'])
        else: log('    КРИТ: +2 ОР цели'); T('crit_kill'); wound(target, 2, p['name'])
    if p.get('bounty_pay'):
        pass

def table_B(p, roll, action, on_succ, on_fail, kind='рпди'):
    T('table_b')
    nat = roll; eff = mod_roll(p, roll, kind)
    if nat == 20: eff = 20; STATE['nat20'] = True
    if nat == 1: eff = 1; STATE['nat1'] = True
    eff = croupier_reroll(p, eff, kind)
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [таблица Б, {action}]')
    if nat == 20 or (nat != 1 and eff >= 15): on_succ()
    elif nat == 1 or eff <= 10: on_fail()
    else: log('    ничего не произошло (11–14)')

def table_V(p, roll, action, on_succ, on_fail):
    T('table_v')
    nat = roll; eff = mod_roll(p, roll, 'рпдс')
    if nat == 20: eff = 20; STATE['nat20'] = True
    if nat == 1: eff = 1; STATE['nat1'] = True
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [таблица В, {action}]')
    if nat == 20 or (nat != 1 and eff >= 11): on_succ()
    elif nat == 1 or eff <= 9: on_fail()
    else: log('    ничего не произошло (10)')

def pick_target(p, need_dmg=False):
    if VARIANT == 'amkary' and rng.random() < 0.85:
        cands = [q for q in alive_list() if q is not p and q['team'] != p['team'] and not q['no_target']]
        if not cands: cands = [q for q in alive_list() if q is not p and not q['no_target']]
    else:
        cands = [q for q in alive_list() if q is not p and not q['no_target']]
    if not cands: cands = [q for q in alive_list() if q is not p]
    if not cands: return None
    if need_dmg:
        soft = [q for q in cands if q['or_'] <= 1]
        if soft and STATE['cycle'] == 1: cands = soft
    return rng.choice(cands)

def cascade_check(actor, target):
    if target is actor: return target
    cs = [p for p in P if p['prof'][0] == 'Каскадёр' and p['alive'] and p is not target and p is not actor]
    if cs and rng.random() < 0.4:
        c = cs[0]
        prof_use(c, 'intercept')
        dispute('cascade')
        log(f'    ПЕРЕХВАТ: P{c["seat"]} объявляет до броска, что принимает действие на себя')
        return c
    return target

def do_steal(p, victim, use_prof=False):
    def succ():
        cc = closed_cards(victim)
        if not cc:
            rv = victim['revealed'][:]
            if not rv: log('    у цели пусто — забирать нечего'); return
            k, c = rng.choice(rv); victim['revealed'].remove((k, c))
        else:
            k, c = rng.choice(cc); victim['hand'][k].remove(c)
        p['hand'].setdefault(k, []).append(c)
        p['cards_gained'] += 1; victim['cards_lost'] += 1
        T('steal_ok')
        if MODS.get('collect_metrics'): STATE['hoard_cards'] += 1
        log(f'    УСПЕХ: P{p["seat"]} забирает у P{victim["seat"]} закрытую карту [{k}]')
    def fail():
        cc = closed_cards(p)
        if cc:
            k, c = rng.choice(cc); p['hand'][k].remove(c)
            victim['hand'].setdefault(k, []).append(c)
            p['cards_lost'] += 1; victim['cards_gained'] += 1
            log(f'    ПРОВАЛ (обратный эффект): P{victim["seat"]} тянет вслепую у P{p["seat"]} карту [{k}]')
        else:
            log(f'    ПРОВАЛ: у P{p["seat"]} вся рука раскрыта — обратный эффект на усмотрение стола')
        T('steal_fail'); dispute('steal_fail')
    if use_prof: prof_use(p, 'steal')
    table_B(p, d20(), 'кража', succ, fail)

def heal_ok(q):
    return q['heal_taken'] < 1 or MODS.get('healcap_off') or q.get('healunlock')

def healer_bonus(p):
    """PRX-11: лечение без лимита, но провал бьёт по автору."""
    if MODS.get('weird') and prof_tag(p) == 'healunlock':
        p['healunlock'] = True
        return True
    return False

def do_heal_action(p, target):
    healer_bonus(p)
    if not heal_ok(target):
        log(f'    лимит лечения P{target["seat"]} в цикле исчерпан — РПДИ сгорает')
        T('act_wasted')
        return
    def succ():
        target['or_'] = max(0, target['or_'] - 1); target['heal_taken'] += 1
        T('heal_ok')
        log(f'    УСПЕХ: с P{target["seat"]} снят 1 ОР → {target["or_"]}')
    def fail():
        log('    ПРОВАЛ (обратный эффект на автора): неумелая помощь')
        T('heal_fail'); wound(p, 1, 'self')
    table_B(p, d20(), f'помощь P{target["seat"]}', succ, fail)

def do_humiliate(p, target):
    def succ():
        cc = closed_cards(target)
        if cc:
            k, c = rng.choice(cc); target['hand'][k].remove(c); target['revealed'].append((k, c))
            target['cards_lost'] += 1
            T('humiliate_ok'); dispute('forced_reveal')
            log(f'    УСПЕХ: P{target["seat"]} публично раскрывает [{k}]')
        else:
            log('    УСПЕХ: P%d теряет карту обмена' % target['seat'])
            target['obmen'] = None
            T('humiliate_ok')
    def fail():
        cc = closed_cards(p)
        if cc:
            k, c = rng.choice(cc); p['hand'][k].remove(c); p['revealed'].append((k, c))
            p['cards_lost'] += 1
            log(f'    ПРОВАЛ (обратный эффект): раскрыт остался P{p["seat"]} — [{k}]')
        else:
            log(f'    ПРОВАЛ: P{p["seat"]} остался ни с чем (без механики)')
        T('humiliate_fail'); dispute('humiliate_fail')
    table_B(p, d20(), f'унижение P{target["seat"]}', succ, fail)

def rpds_world(p):
    T('rpds')
    if DRAW['ИНВЕНТАРЬ']:
        item = DRAW['ИНВЕНТАРЬ'].pop()
        def succ():
            p['hand'].setdefault('ИНВЕНТАРЬ', []).append(item)
            p['cards_gained'] += 1; STATE['hoard_cards'] += 1
            log('    УСПЕХ: найдено в мире → в руку [ИНВЕНТАРЬ]')
        def fail(): log('    ПРОВАЛ: мир не дал ничего (обратный эффект — художественный)')
        table_V(p, d20(), 'РПДС: обыск мира', succ, fail)

def rpds_heal_self(p):
    T('rpds')
    def succ():
        p['or_'] = max(0, p['or_'] - 1); p['heal_taken'] += 1
        T('selfheal_ok')
        log(f'    УСПЕХ самолечения: −1 ОР → {p["or_"]}')
    def fail():
        log('    ПРОВАЛ самолечения: стало только хуже')
        p['heal_taken'] += 1; wound(p, 1, 'self')
    table_V(p, d20(), 'РПДС: самолечение', succ, fail)

def draw_cards(p, k, tag='collect'):
    """Тянет k карт из колоды (механика собирательства). Возвращает число вытянутых."""
    got = 0
    cats = [c for c in DRAW if DRAW[c]]
    for _ in range(k):
        if not cats: break
        cat = rng.choice(cats)
        if not DRAW[cat]:
            cats = [c for c in DRAW if DRAW[c]]
            if not cats: break
            cat = rng.choice(cats)
        p['hand'].setdefault(cat, []).append(DRAW[cat].pop())
        p['cards_gained'] += 1; got += 1
    if got:
        STATE['hoard_cards'] += got
        STATE['collect_total'] += got
        p['collect_n'] += got
        T('collect', got)
    return got

def do_collect(p):
    """РПДИ/РПДС на собирательство: 1 бросок по таблице В, успех = 2 карты, провал = 0."""
    def succ():
        n = draw_cards(p, 2)
        log(f'    УСПЕХ собирательства: +{n} карт в руку')
    def fail():
        log('    ПРОВАЛ собирательства: ничего не найдено')
        T('collect_fail')
    table_V(p, d20(), 'собирательство', succ, fail)

def use_obmen(p, rpds_left, rpdi_left):
    if not p['obmen'] or rpds_left + rpdi_left == 0: return rpds_left, rpdi_left
    name, txt = p['obmen']
    if STATE.get('silence'):
        return rpds_left, rpdi_left
    op = p['pr'].get('obmen_p', 1.0)
    use = False
    if name == 'Парамедик' and p['or_'] >= 1 and heal_ok(p): use = rng.random() < 0.8 * op
    elif name == 'Отмена' and STATE['last_wound'] and STATE['last_wound'][0] == p['seat'] and p['or_'] >= 1: use = rng.random() < 0.75 * op
    elif name == 'Взятка': use = False
    elif name in ('Заначка', 'Обмен', 'Второе дыхание', 'Свидетель', 'Подстава'): use = rng.random() < 0.45 * op
    elif name in ('Сделка', 'Сбор', 'Щит', 'Перевод', 'Торг'): use = rng.random() < 0.55 * op
    if not use: return rpds_left, rpdi_left
    log(f'    КАРТА ОБМЕНА: P{p["seat"]} тратит неиспользованное РПД — механика «{name}»')
    p['obmen_uses'] += 1; STATE['obmen_uses'] += 1; T('obmen')
    T('narrate_u', p['pr'].get('narrate', 1.0))
    if name == 'Парамедик':
        p['or_'] = max(0, p['or_'] - 1); p['heal_taken'] += 1
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Отмена':
        seat, amt = STATE['last_wound']; q = by_seat(seat)
        q['or_'] = max(0, q['or_'] - amt); STATE['last_wound'] = None
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Заначка':
        for _ in range(2):
            k = rng.choice(list(DRAW.keys()))
            if DRAW[k]: p['hand'].setdefault(k, []).append(DRAW[k].pop())
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Обмен':
        t = pick_target(p)
        if t is None:
            p['obmen'] = None
            return rpds_left, rpdi_left
        cc1, cc2 = closed_cards(p), closed_cards(t)
        if cc1 and cc2:
            k1, c1 = rng.choice(cc1); k2, c2 = rng.choice(cc2)
            p['hand'][k1].remove(c1); t['hand'][k2].remove(c2)
            p['hand'].setdefault(k2, []).append(c2); t['hand'].setdefault(k1, []).append(c1)
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Свидетель':
        t = pick_target(p)
        if t is None:
            p['obmen'] = None
            return rpds_left, rpdi_left
        cc = closed_cards(t)
        if cc:
            k, c = rng.choice(cc); t['hand'][k].remove(c); t['revealed'].append((k, c))
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Второе дыхание':
        rpds_left += 1
        if rpdi_left: rpdi_left -= 1
    elif name == 'Подстава':
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Сбор':
        draw_cards(p, 3, 'obmen')
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Сделка':
        t = pick_target(p)
        cc1, cc2 = closed_cards(p), (closed_cards(t) if t else [])
        if t is not None and len(cc1) >= 2 and cc2:
            for _ in range(2):
                k1, c1 = rng.choice(closed_cards(p)); p['hand'][k1].remove(c1); p['cards_lost'] += 1
                t['hand'].setdefault(k1, []).append(c1); t['cards_gained'] += 1
            k2, c2 = rng.choice(closed_cards(t)); t['hand'][k2].remove(c2)
            p['hand'].setdefault(k2, []).append(c2); p['cards_gained'] += 1; t['cards_lost'] += 1
            T('weird'); dispute('swap')
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Щит':
        p['immune'] = STATE['cycle']
        T('immunity')
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Перевод':
        t = pick_target(p)
        if t is not None and p['or_'] >= 1:
            p['or_'] -= 1; t['or_'] += 1
            T('weird'); dispute('weird')
            log(f'    ПЕРЕВОД: 1 ОР с P{p["seat"]} на P{t["seat"]}')
            if t['or_'] >= STATE['dth']: check_death(t, 'перевод ОР', p['name'])
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    elif name == 'Торг':
        gs = [g for g in ghosts() if g['tokens'] >= 1]
        if gs:
            g = rng.choice(gs); g['tokens'] -= 1; p['tokens'] += 1
            T('weird')
            log(f'    ТОРГ: P{p["seat"]} забирает жетон у призрака P{g["seat"]}')
        if rpdi_left: rpdi_left -= 1
        else: rpds_left -= 1
    p['obmen'] = None
    return rpds_left, rpdi_left

ONCE_TAGS = ('cancel', 'eyes', 'fake', 'voice', 'photo')

def _ghost_apply(g, tag):
    living = alive_list()
    if not living: return
    if tag == 'knock':
        for q in living: q['no_rpds'] = True
    elif tag == 'cold':
        rng.choice(living)['no_rpds'] = True
    elif tag == 'name':
        q = max(living, key=lambda x: x['or_']); q['no_target'] = True
    elif tag == 'cancel':
        if STATE['last_wound']:
            seat, amt = STATE['last_wound']; q = by_seat(seat)
            q['or_'] = max(0, q['or_'] - amt); STATE['last_wound'] = None
            dispute('cancel')
    elif tag == 'buff':
        rng.choice(living)['buff'] = 1
    elif tag == 'mirror':
        q = rng.choice(living); cc = closed_cards(q)
        if cc:
            k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
            q['cards_lost'] += 1
            dispute('forced_reveal')
    elif tag == 'eyes':
        rng.choice(living)['skip_reveal'] = True
    elif tag == 'dark':
        STATE['dark'] = True
    elif tag == 'fake':
        q = rng.choice(living)
        if DRAW['ИНВЕНТАРЬ']:
            q['hand'].setdefault('ИНВЕНТАРЬ', []).append(DRAW['ИНВЕНТАРЬ'].pop())
            q['cards_gained'] += 1
    elif tag == 'voice':
        q = rng.choice(living); cc = closed_cards(q)
        if q['obmen']: q['obmen'] = None
        elif cc:
            k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
            q['cards_lost'] += 1
    elif tag == 'pain':
        hurt = [q for q in living if q['or_'] >= 1 and q['heal_taken'] < 1]
        if hurt:
            q = max(hurt, key=lambda x: x['or_']); q['or_'] -= 1; q['heal_taken'] += 1
    elif tag == 'photo':
        for q in living:
            cc = closed_cards(q)
            if cc:
                k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
                q['cards_lost'] += 1
        dispute('forced_reveal')
    elif tag == 'queue':
        STATE['queue_shift'] = True
    # ---------- новые механики карт мёртвых (режим weird) ----------
    elif tag == 'mass_reveal':
        for q in living:
            cc = closed_cards(q)
            if cc:
                k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
                q['cards_lost'] += 1
        T('weird'); STATE['weird_events'] += 1; dispute('forced_reveal')
    elif tag == 'token_tax':
        for q in ghosts():
            if q is not g and q['tokens'] >= 1:
                q['tokens'] -= 1; g['tokens'] += 1
        T('weird'); STATE['weird_events'] += 1
    elif tag == 'curse':
        q = rng.choice(living); q['curse'] = 2
        T('weird'); STATE['weird_events'] += 1; dispute('weird')
    elif tag == 'swap_or':
        if len(living) >= 2:
            a, b = rng.sample(living, 2)
            a['or_'], b['or_'] = b['or_'], a['or_']
            T('weird'); STATE['weird_events'] += 1; dispute('weird')
            for q in (a, b):
                if q['or_'] >= STATE['dth']: check_death(q, 'обмен ОР', 'карта мёртвых')
    elif tag == 'fake_death':
        q = rng.choice(living); q['frozen'] = True; q['no_target'] = True
        T('weird'); STATE['weird_events'] += 1; dispute('weird')
    elif tag == 'silence':
        STATE['silence'] = True
        T('weird'); STATE['weird_events'] += 1
    elif tag == 'harvest_x2':
        STATE['harvest_x2'] = True
        T('weird'); STATE['weird_events'] += 1
    elif tag == 'ghost_king':
        g['tokens'] += 3; g['veto_revive'] = True
        T('weird'); STATE['weird_events'] += 1
    elif tag == 'hand_lock':
        q = rng.choice(living); q['no_steal'] = True
        T('weird'); STATE['weird_events'] += 1
    elif tag == 'reroll_bad':
        q = rng.choice(living); q['curse'] = max(q['curse'], 2)
        T('weird'); STATE['weird_events'] += 1

def ghost_use_card(g, card=None):
    """card=None — стандартный путь (одна карта в g['ghostcard']).
       иначе применяется конкретная карта (режим teny_k = 2..3)."""
    single = card is None
    if single:
        if g['ghostcard'] is None: return
        tag, text = g['ghostcard']
    else:
        tag, text = card
    if tag in g['ghost_used'] and tag in ONCE_TAGS: return
    living = alive_list()
    if not living: return
    log(f'  ПРИЗРАК P{g["seat"]}: карта мёртвых, механика «{tag}»')
    g['ghost_used'].add(tag)
    STATE['cur'] = g
    T('ghost_cards'); STATE['ghost_uses'] += 1
    T('narrate_u', g['pr'].get('narrate', 1.0))
    T('chatter_u', 0.3 * g['pr'].get('chatter', 1.0))
    dispute('ghost')
    _ghost_apply(g, tag)
    if single: g['ghostcard'] = None

def ghost_bets():
    for g in ghosts():
        if g['tokens'] >= 1 and rng.random() < 0.85:
            if len(alive_list()) >= 6: k = rng.choices([0, 1, 2], weights=[1, 5, 2])[0]
            else: k = rng.choices([1, 2, 3], weights=[2, 4, 2])[0]
            stake = 1 if g['tokens'] < 3 else rng.choice([1, 2])
            stake = min(stake, g['tokens']); g['tokens'] -= stake
            g['bet'] = (stake, k)
            T('bets')
            log(f'  ПРИЗРАК P{g["seat"]}: ставка {stake} жет. на ровно {k} выбывших за цикл')
        else: g['bet'] = None

def resolve_bets(cd):
    for g in ghosts():
        if g['bet']:
            stake, k = g['bet']
            if k == cd:
                g['tokens'] += stake * 2; STATE['bet_hits'] += 1
                T('bet_hits')
                log(f'  СТАВКА СЫГРАЛА: P{g["seat"]} угадал {k} → +{stake*2} жет.')
            g['bet'] = None

def ghost_shop(g):
    if g['tokens'] >= 3 and rng.random() < 0.4:
        g['tokens'] -= 1; T('shop')
        log(f'  МАГАЗИН МЁРТВЫХ: P{g["seat"]} за 1 жет. подсматривает карты живого')
    if g['tokens'] >= 2 and rng.random() < 0.25:
        g['tokens'] -= 2; T('shop')
        q = rng.choice(alive_list()); cc = closed_cards(q)
        if cc:
            k, c = rng.choice(cc); q['hand'][k].remove(c); q['revealed'].append((k, c))
            q['cards_lost'] += 1
            dispute('forced_reveal')
            log(f'  МАГАЗИН МЁРТВЫХ: P{g["seat"]} за 2 жет. принудительно раскрывает карту P{q["seat"]}')

def try_token_revive():
    gs = [g for g in ghosts() if g['died_cycle'] is not None and STATE['cycle'] - g['died_cycle'] >= 1]
    if not gs: return
    total = sum(g['tokens'] for g in gs)
    price = int(MODS.get('revive_cost', 5 if MODS.get('revive5') else 6))
    medik = any(p['alive'] and p['prof'][0] == 'Медик' for p in P)
    vgs = [g for g in gs if g.get('veto_revive')]
    if vgs and MODS.get('weird'):
        for g in vgs: g['veto_revive'] = False
        log('  ВЕТО ПРИЗРАКА: воскрешение в этом цикле отменено (механика карты мёртвых)')
        T('weird'); dispute('veto')
        return
    if total >= price and (medik or rng.random() < 0.5):
        gs.sort(key=lambda g: (g['died_cycle'], g['seat']))
        r = gs[0]
        for g in gs: g['tokens'] = 0
        r['alive'] = True; r['or_'] = 0; r['tokens'] = 0; r['resurrected'] = True; r['heal_taken'] = 0
        r['frozen'] = False; r['curse'] = 0
        STATE['token_revive'] = True
        T('revives'); T('discuss_e', 1.0); dispute('revive')
        log(f'  ВОСКРЕШЕНИЕ: призраки скидывают жетоны общаком ({total}) — P{r["seat"]} возвращается с 0 ОР')

def mass_action(p):
    if VARIANT == 'amkary':
        cands = [q for q in alive_list() if q is not p and q['team'] != p['team'] and not q['no_target']]
        if len(cands) < 2: cands = [q for q in alive_list() if q is not p and not q['no_target']]
    else:
        cands = [q for q in alive_list() if q is not p and not q['no_target']]
    if len(cands) < 2: return False
    targets = rng.sample(cands, 2)
    thr = 15 if MODS.get('mass_low') else 18
    log(f'  P{p["seat"]}: МАССОВОЕ РПДИ (РАНЕНИЕ) против P{targets[0]["seat"]} и P{targets[1]["seat"]} — порог {thr}–20')
    nat = d20(); eff = mod_roll(p, nat, 'mass')
    log(f'    d20 = {nat}' + (f' (эфф. {eff})' if eff != nat else '') + f' [порог {thr}]')
    if eff >= thr:
        for t in targets: wound(t, 1, p['name'])
        log('    УСПЕХ массового действия: каждой цели +1 ОР')
        T('mass_ok')
    else:
        log('    ПРОВАЛ массового действия: обратный эффект — атакующему +2 ОР')
        T('mass_fail'); dispute('mass_fail')
        wound(p, 2, 'self')
    STATE['mass_count'] += 1
    T('discuss_e', 0.35)
    return True

# цикл активации новых механик спецкарт (legacy-теги сохраняют свои циклы)
SPEC_CYCLE = {
 'swap_hands': 2, 'ghost_cycle': 3, 'steal_prof': 2, 'chaos_swap': 4, 'reflect': 3,
 'duplicate': 2, 'veto': 3, 'reveal_all': 2, 'debt': 3, 'shield_ally': 2,
 'transfer': 4, 'second_life': 0, 'bounty': 2, 'time_lock': 3, 'hoard_bonus': 2,
 'double_turn': 4,
}

def spec_gate(p):
    """Вероятность применения спецкарты зависит от профиля. В базовом режиме
    (профиль neutral) дополнительных бросков нет — воспроизводимость сохраняется."""
    if p['pkey'] == 'neutral' and not MODS.get('spec_gate'):
        return True
    g = p['pr'].get('spec_p', 0.8)
    if MODS.get('spec_hot'): g = min(1.0, g + 0.25)
    if MODS.get('spec_cold'): g = max(0.0, g - 0.35)
    return rng.random() < g

def spec_ready(p, c):
    if MODS.get('spec_any'): return c >= 2
    return True

def spec_bits(p, c, rpdi_left):
    if p.get('spec_lock'): return rpdi_left
    used = p.setdefault('spec_used_set', set())
    for si in range(len(p['specs'])):
        if si in used: continue
        if si == 0 and p['spec_used']: continue
        tag, text = p['specs'][si]
        base_c = SPEC_CYCLE.get(tag, {'additem':2,'extra':3,'immune':3,'lootdead':3,
                                       'fullheal':4,'avoid':4,'revive':5,'autohit':5}.get(tag, 3))
        if MODS.get('spec_any'):
            if c < 2: continue
        elif c != base_c and not (tag in ('lootdead','revive','autohit') and c >= base_c):
            continue
        if tag == 'second_life':
            used.add(si); continue                      # пассивная: срабатывает при гибели
        if not spec_gate(p): continue
        fired = _spec_fire(p, tag, c, si, used)
        if fired and si == 0: p['spec_used'] = True
    return STATE.pop('_rpdi_delta', 0) + rpdi_left

def _spec_fire(p, tag, c, si, used):
    """Применяет одну механику спецкарты. Возвращает True, если сработала."""
    def act():
        used.add(si)
        p['spec_used_n'] += 1; p['spec_uses'] += 1
        STATE['spec_uses'] += 1; T('specs'); dispute('spec')
        log(f'  СПЕЦКАРТА P{p["seat"]}: механика «{tag}»')
    living = [q for q in alive_list() if q is not p]
    # ---------- legacy-механики (порядок ветвей сохранён) ----------
    if tag == 'additem':
        if DRAW['ИНВЕНТАРЬ']:
            act(); p['hand'].setdefault('ИНВЕНТАРЬ', []).append(DRAW['ИНВЕНТАРЬ'].pop())
            p['cards_gained'] += 1
            return True
        return False
    if tag == 'extra':
        act(); STATE['_rpdi_delta'] = STATE.get('_rpdi_delta', 0) + 1
        return True
    if tag == 'immune':
        if rng.random() < 0.8:
            act(); p['immune'] = c; T('immunity'); return True
        return False
    if tag == 'lootdead':
        if ghosts():
            g = rng.choice(ghosts()); cc = closed_cards(g)
            if cc:
                act()
                k, card = rng.choice(cc); g['hand'][k].remove(card)
                p['hand'].setdefault(k, []).append(card); p['cards_gained'] += 1
                return True
        return False
    if tag == 'fullheal':
        hurt = [q for q in alive_list() if q['or_'] >= 1]
        if hurt:
            q = max(hurt, key=lambda x: x['or_']); act(); q['or_'] = 0; return True
        return False
    if tag == 'avoid':
        act(); p['spec_armed'] = True; return True
    if tag == 'revive':
        if ghosts() and not STATE['spec_revive']:
            gs = sorted(ghosts(), key=lambda g: (g['died_cycle'] or 99))
            act(); r = gs[0]
            r['alive'] = True; r['or_'] = 0; r['debuff'] = True; r['resurrected'] = True
            r['frozen'] = False
            STATE['spec_revive'] = True; T('revives'); T('discuss_e', 1.0); dispute('revive')
            return True
        return False
    if tag == 'autohit':
        t = max(alive_list(), key=lambda x: (x['or_'], rng.random()))
        if t is p: t = pick_target(p) or t
        if t is not p:
            act()
            log(f'    заявлено гарантированное поражение P{t["seat"]} (бросок не нужен)')
            wound(t, 2, p['name'])
            return True
        return False
    # ---------- новые механики (режим weird) ----------
    if tag == 'swap_hands' and living:
        t = rng.choice(living)
        h1, h2 = dict(p['hand']), dict(t['hand'])
        p['hand'], t['hand'] = h2, h1
        act(); T('weird'); STATE['weird_events'] += 1; dispute('swap')
        log(f'    ОБМЕН РУКАМИ: P{p["seat"]} ↔ P{t["seat"]}')
        return True
    if tag == 'ghost_cycle':
        act(); p['gcycle'] = True; p['no_target'] = True; p['tokens'] += 2
        T('weird'); STATE['weird_events'] += 1; dispute('weird')
        return True
    if tag == 'steal_prof' and living:
        t = rng.choice(living)
        p['prof'], t['prof'] = t['prof'], ('none', 'профессия забрана', 'none')
        act(); T('weird'); STATE['weird_events'] += 1; dispute('weird')
        log(f'    ЗАХВАТ ПРОФЕССИИ: P{p["seat"]} забирает профессию P{t["seat"]}')
        return True
    if tag == 'chaos_swap':
        lv = alive_list()
        if len(lv) >= 2:
            hands = [dict(q['hand']) for q in lv]
            for i, q in enumerate(lv): q['hand'] = hands[i - 1]
            act(); T('weird'); STATE['weird_events'] += 1; dispute('swap')
            return True
        return False
    if tag == 'reflect':
        act(); STATE['reflect_cycle'] = c
        T('weird'); STATE['weird_events'] += 1; dispute('reflect')
        return True
    if tag == 'duplicate':
        act(); p['dup_ready'] = True; T('weird'); STATE['weird_events'] += 1
        return True
    if tag == 'veto':
        act(); STATE['veto_holder'] = p['seat']; STATE['veto_pending'] = True
        T('weird'); STATE['weird_events'] += 1; dispute('veto')
        return True
    if tag == 'reveal_all':
        for q in alive_list():
            for _ in range(2):
                cc = closed_cards(q)
                if cc:
                    k, c2 = rng.choice(cc); q['hand'][k].remove(c2); q['revealed'].append((k, c2))
                    q['cards_lost'] += 1
        act(); T('weird'); STATE['weird_events'] += 1; dispute('forced_reveal')
        return True
    if tag == 'debt' and living:
        t = rng.choice(living); t['debt'] = 2
        act(); T('weird'); STATE['weird_events'] += 1; dispute('weird')
        return True
    if tag == 'shield_ally' and living:
        t = rng.choice(living); t['immune'] = c + 1
        act(); T('weird'); T('immunity'); STATE['weird_events'] += 1
        return True
    if tag == 'transfer' and living and p['or_'] >= 1:
        t = rng.choice(living)
        amt = p['or_']; p['or_'] = 0; t['or_'] += amt
        act(); T('weird'); STATE['weird_events'] += 1; dispute('weird')
        if t['or_'] >= STATE['dth']: check_death(t, 'перенос ОР', p['name'])
        return True
    if tag == 'bounty' and living:
        t = rng.choice(living); t['bounty_on'] = True; STATE['bounty_seat'] = t['seat']
        act(); T('weird'); STATE['weird_events'] += 1; dispute('bounty')
        return True
    if tag == 'time_lock':
        act(); STATE['no_kill_cycle'] = c; STATE['no_kill'] = True
        T('weird'); STATE['weird_events'] += 1; dispute('weird')
        return True
    if tag == 'hoard_bonus':
        act(); draw_cards(p, 3, 'spec'); T('weird'); STATE['weird_events'] += 1
        return True
    if tag == 'double_turn':
        act(); STATE['_rpdi_delta'] = STATE.get('_rpdi_delta', 0) + 2
        T('weird'); STATE['weird_events'] += 1
        return True
    return False

def choose_rpdi(p, c):
    gs = ghosts()
    if c == 1: opts, wts = ['humiliate','wound','steal','skip','heal'], [35,25,15,20,5]
    elif c == 2: opts, wts = ['wound','kill','steal','humiliate','heal','skip'], [30,25,12,13,10,10]
    elif c == 3: opts, wts = ['wound','kill','steal','humiliate','heal','skip','marauder'], [18,6,12,14,12,28,10 if gs else 0]
    elif c == 4: opts, wts = ['wound','kill','steal','humiliate','heal','skip','marauder','mass'], [24,16,10,10,10,15,10 if gs else 0,10]
    else: opts, wts = ['wound','kill','steal','humiliate','heal','skip','marauder'], [26,30,8,6,8,10,12 if gs else 0]
    if p['prof'][0] == 'Вор' and p['thief_left'] > 0 and c >= 2 and 'steal' in opts:
        wts[opts.index('steal')] += 15
    if p['prof'][0] == 'Медик' and 'heal' in opts: wts[opts.index('heal')] += 8
    if not [q for q in alive_list() if q is not p and q['or_'] >= 1 and heal_ok(q)] and 'heal' in opts:
        wts[opts.index('heal')] = 0
    # ----- собирательство как отдельное РП-действие -----
    if MODS.get('collect') or p['pr'].get('hoard'):
        opts.append('collect'); wts.append(int(MODS.get('collect_w', 10)))
    # ----- профильные поправки весов -----
    for k, v in p['pr'].get('w', {}).items():
        if k in opts: wts[opts.index(k)] += v
    if MODS.get('hoard_bias') and p['pkey'] == 'neutral':
        for k, v in dict(steal=15, collect=15, kill=-15, wound=-8, humiliate=-5).items():
            if k in opts: wts[opts.index(k)] += v
    # ----- ограничения ситуации и механик -----
    if VARIANT == 'arena':
        for k in ('heal',): 
            if k in opts: wts[opts.index(k)] = 0
    if VARIANT == 'silent' and 'humiliate' in opts: wts[opts.index('humiliate')] = 0
    if p['no_steal'] and 'steal' in opts: wts[opts.index('steal')] = 0
    if (STATE.get('no_kill') or MODS.get('no_kill')) and 'kill' in opts: wts[opts.index('kill')] = 0
    if not gs and 'marauder' in opts: wts[opts.index('marauder')] = 0
    if MODS.get('collect_only'):
        for k in ('wound','kill','humiliate','mass'):
            if k in opts: wts[opts.index(k)] = 0
        if 'collect' not in opts:
            opts.append('collect'); wts.append(40)
        else:
            wts[opts.index('collect')] += 40
    wts = [max(0, w) for w in wts]
    if sum(wts) == 0: return 'skip'
    return rng.choices(opts, weights=wts)[0]

def try_veto(actor, kind):
    """PRX-09 (раз в игру) и спецкарта «veto»: отмена заявленного действия до броска.
    В базовом режиме держателей нет — функция выходит без расхода ГСЧ."""
    if not MODS.get('weird'): return False
    holders = [q for q in alive_list() if q is not actor and (
        (prof_tag(q) == 'veto' and not q['veto_used']) or
        (STATE.get('veto_holder') == q['seat'] and STATE.get('veto_pending')))]
    if not holders: return False
    h = holders[0]
    if rng.random() >= 0.30 * h['pr'].get('prof_p', 0.75): return False
    if prof_tag(h) == 'veto' and not h['veto_used']:
        h['veto_used'] = True; prof_use(h, 'veto')
    else:
        STATE['veto_pending'] = False; STATE['veto_holder'] = None
        T('specs'); dispute('veto')
    STATE['vetoes'] += 1; STATE['weird_events'] += 1
    T('veto'); T('weird')
    log(f'    ВЕТО: P{h["seat"]} отменяет заявленное действие P{actor["seat"]} («{kind}») до броска')
    return True

def prof_phase(p, c, rpdi_left):
    """Активация новых профессий PRX-01…14 (только режим weird; в базовом — 0 ГСЧ)."""
    if not MODS.get('weird'): return rpdi_left
    tag = prof_tag(p)
    if not tag or tag == 'none': return rpdi_left
    g = p['pr'].get('prof_p', 0.75)
    living = [q for q in alive_list() if q is not p]
    if tag == 'drawcard' and p['draw_used'] != c and rng.random() < 0.6 * g:
        p['draw_used'] = c; prof_use(p, 'draw'); draw_cards(p, 1, 'prof')
        log(f'    PRX-05: P{p["seat"]} берёт карту из колоды (свободное действие)')
    elif tag == 'order' and p['order_used'] != c and rng.random() < 0.4 * g:
        p['order_used'] = c; STATE['order_next'] = True; prof_use(p, 'order')
        log(f'    PRX-02: P{p["seat"]} сдвигает порядок хода (со следующего цикла)')
    elif tag == 'speclock' and p['speclock_used'] != c and living and rng.random() < 0.45 * g:
        t = rng.choice(living); t['spec_lock'] = True
        p['speclock_used'] = c; prof_use(p, 'speclock')
        T('weird'); STATE['weird_events'] += 1
        log(f'    PRX-03: P{p["seat"]} блокирует спецкарту P{t["seat"]} до конца цикла')
    elif tag == 'forceswap' and p['forceswap_used'] != c and len(living) >= 2 and rng.random() < 0.4 * g:
        a, b = rng.sample(living, 2)
        a['revealed'], b['revealed'] = b['revealed'], a['revealed']
        p['forceswap_used'] = c; prof_use(p, 'forceswap')
        T('weird'); STATE['weird_events'] += 1
        log(f'    PRX-08: P{p["seat"]} меняет раскрытые карты P{a["seat"]} и P{b["seat"]}')
    elif tag == 'stealprof' and not p['stealprof_used'] and living and rng.random() < 0.25 * g:
        t = rng.choice(living)
        p['prof'], t['prof'] = t['prof'], ('none', 'профессия забрана', 'none')
        p['stealprof_used'] = True; prof_use(p, 'stealprof')
        T('weird'); STATE['weird_events'] += 1
        log(f'    PRX-01: P{p["seat"]} забирает профессию P{t["seat"]} до конца партии')
    elif tag == 'copyspec' and not p.get('copyspec_used') and living and rng.random() < 0.3 * g:
        cands = [q for q in living if q['specs']]
        if cands:
            t = rng.choice(cands); tg = t['specs'][0][0]
            used = p.setdefault('spec_used_set', set())
            if _spec_fire(p, tg, c, 'copy%d' % c, used):
                p['copyspec_used'] = True; prof_use(p, 'copyspec')
                rpdi_left += STATE.pop('_rpdi_delta', 0)
    return rpdi_left

def _do_act(p, c, act):
    """Исполнение одного РПДИ. Порядок вызовов ГСЧ совпадает с базовой версией turn();
    добавлены только счётчики и ветви под гардами (weird/моды)."""
    if act == 'skip':
        log('    РПДИ сэкономлено — карта обмена наготове')
        return
    T('acted'); T('narrate_u', p['pr'].get('narrate', 1.0))
    if act == 'collect':
        log(f'    РПДИ: собирательство — P{p["seat"]} ищет карты')
        do_collect(p)
    elif act == 'mass':
        if not mass_action(p):
            log('    массовое действие не прошло по целям'); p['wasted'] += 1; T('act_wasted')
    elif act == 'marauder':
        g = rng.choice(ghosts()); cc = closed_cards(g)
        log(f'    РПДИ-мародёрство: тянет вслепую с трупа P{g["seat"]}')
        if cc:
            def succ():
                k, card = rng.choice(closed_cards(g)); g['hand'][k].remove(card)
                p['hand'].setdefault(k, []).append(card)
                p['cards_gained'] += 1; g['cards_lost'] += 1
            def fail(): log('    ПРОВАЛ: труп не отдаёт карту (обратный эффект — по вкусу стола)')
            table_B(p, d20(), 'мародёрство', succ, fail)
        else: log('    на трупе пусто')
    elif act == 'wound':
        t = pick_target(p, need_dmg=True); t = cascade_check(p, t)
        if t is None: p['wasted'] += 1; T('act_wasted')
        elif try_veto(p, 'wound'): p['wasted'] += 1; T('act_wasted')
        else:
            log(f'    РПДИ: заявлено РАНЕНИЕ P{t["seat"]}'); table_A(p, d20(), 'РАНЕНИЕ', t)
    elif act == 'kill':
        t = pick_target(p); t = cascade_check(p, t)
        if t is None: p['wasted'] += 1; T('act_wasted')
        elif MODS.get('weird') and prof_tag(p) == 'safekill' and t['or_'] >= 2 and \
                rng.random() < 0.6 * p['pr'].get('prof_p', 0.75):
            prof_use(p, 'safekill'); T('weird'); STATE['weird_events'] += 1; dispute('weird')
            log(f'    PRX-10: гарантированное поражение P{t["seat"]} без броска (у цели 2+ ОР)')
            p['kills'] += 1
            check_death(t, 'профессия PRX-10', p['name'])
        elif try_veto(p, 'kill'): p['wasted'] += 1; T('act_wasted')
        else:
            log(f'    РПДИ: заявлено УБИЙСТВО P{t["seat"]}'); table_A(p, d20(), 'УБИЙСТВО', t)
    elif act == 'steal':
        t = pick_target(p)
        if t is None: p['wasted'] += 1; T('act_wasted')
        elif try_veto(p, 'steal'): p['wasted'] += 1; T('act_wasted')
        else:
            use_prof = p['prof'][0] == 'Вор' and p['thief_left'] > 0
            if use_prof: p['thief_left'] -= 1
            log(f'    РПДИ: кража у P{t["seat"]}' + (' (профессия «Вор»)' if use_prof else '') + ' вслепую')
            do_steal(p, t, use_prof=use_prof)
    elif act == 'heal':
        t = max([q for q in alive_list() if q is not p and q['or_'] >= 1 and heal_ok(q)], key=lambda x: x['or_'], default=None)
        if t is None: p['wasted'] += 1; T('act_wasted')
        else:
            log(f'    РПДИ: помощь/лечение P{t["seat"]}'); do_heal_action(p, t)
    elif act == 'humiliate':
        t = pick_target(p); t = cascade_check(p, t)
        if t is None: p['wasted'] += 1; T('act_wasted')
        elif try_veto(p, 'humiliate'): p['wasted'] += 1; T('act_wasted')
        else:
            log(f'    РПДИ: унижение P{t["seat"]}'); do_humiliate(p, t)

def turn(p, c):
    log(f'  ——— P{p["seat"]} ({p["prof"][0]}), ОР={p["or_"]} ———')
    STATE['cur'] = p
    T('turns')
    T('think_u', p['pr'].get('think', 1.0))
    T('chatter_u', 0.5 * p['pr'].get('chatter', 1.0))
    if p.get('frozen'):
        T('skip_turns')
        log('    игрок до конца цикла считается выбывшим (механика «мнимая смерть») — ход пропущен')
        return
    rev, rpds_left, rpdi_left = sched(c)
    if MODS.get('rpds_off'): rpds_left = 0
    rpdi_left += MODS.get('rpdi_extra', 0)
    if p['debuff']: rpdi_left = max(0, rpdi_left - 1)
    if p.get('extralate') and c >= 3: rpdi_left += 1
    if p.get('debt', 0) > 0:
        rpdi_left = max(0, rpdi_left - 1); p['debt'] -= 1
        log(f'    ДОЛГ (спецкарта): у P{p["seat"]} на 1 РПДИ меньше')
    for i in range(rev): reveal(p)
    if p['no_rpds']:
        rpds_left = 0; p['no_rpds'] = False
    if rpds_left > 0:
        if p['or_'] >= 1 and (c > 1 or p['or_'] == 1) and rng.random() < 0.55:
            log('    РПДС: самолечение'); rpds_heal_self(p); rpds_left -= 1
            T('narrate_u', p['pr'].get('narrate', 1.0))
        elif p['prof'][0] == 'Стример' and rng.random() < 0.6:
            log('    РПДС + «Стример»: стрим с донатами')
            def succ():
                if DRAW['ИНВЕНТАРЬ']: p['hand'].setdefault('ИНВЕНТАРЬ', []).append(DRAW['ИНВЕНТАРЬ'].pop())
            def fail(): log('    ПРОВАЛ: стрим забанили (обратный эффект — narrativный)')
            table_V(p, d20(), 'стрим', succ, fail); rpds_left -= 1
            T('narrate_u', p['pr'].get('narrate', 1.0))
        elif rng.random() < 0.75:
            log('    РПДС: взаимодействие с миром'); rpds_world(p); rpds_left -= 1
            T('narrate_u', p['pr'].get('narrate', 1.0))
    rpdi_left = spec_bits(p, c, rpdi_left)
    rpdi_left = prof_phase(p, c, rpdi_left)
    if p['gcycle']:
        T('skip_turns')
        log(f'    P{p["seat"]} до конца цикла — призрак: дальше не действует')
        return
    if VARIANT == 'market' and p['tokens'] >= 1 and rng.random() < 0.5:
        p['tokens'] -= 1; STATE['market_buys'] += 1; T('market')
        draw_cards(p, 1, 'market')
        log(f'    РЫНОК: P{p["seat"]} тратит жетон — покупает карту из колоды')
    took = False
    while rpdi_left > 0:
        act = choose_rpdi(p, c)
        _do_act(p, c, act)
        if act != 'skip': took = True
        rpdi_left -= 1
        if act in ('wound', 'kill', 'steal', 'humiliate', 'mass', 'marauder') and \
                p.get('dup_ready') and MODS.get('weird'):
            p['dup_ready'] = False
            STATE['dups'] += 1; T('weird'); dispute('weird')
            T('narrate_u', p['pr'].get('narrate', 1.0))
            log(f'    ДУБЛЬ: P{p["seat"]} повторяет действие «{act}» (механика спецкарты)')
            _do_act(p, c, act)
    if not took: STATE['idle_seats'].add(p['seat'])
    rpds_left, rpdi_left = use_obmen(p, rpds_left, rpdi_left)

def rotate_hands():
    seats = sorted(P, key=lambda x: x['seat'])
    hands = [dict(pl['hand']) for pl in seats]
    for i, pl in enumerate(seats):
        pl['hand'] = hands[i - 1]
    STATE['rotations'] += 1
    log('  🔄 КОНЕЦ ЦИКЛА: все закрытые карты характеристик сдвигаются по кругу (эффект ситуации)')

def run_cycle(c):
    STATE['cycle'] = c
    STATE['player_death'] = False; STATE['dark'] = False
    STATE['last_wound'] = None; STATE['queue_shift'] = None
    T('cycles')
    for p in P:
        p['frozen'] = False; p['gcycle'] = False; p['spec_lock'] = False
        p['no_steal'] = False; p['curse'] = 0
    STATE['silence'] = False; STATE['no_kill'] = False; STATE['harvest_x2'] = False
    STATE['idle_seats'] = set(); STATE['bounty_seat'] = None; STATE['reflect_cycle'] = None
    if STATE.get('order_next'):
        STATE['queue_shift'] = True; STATE['order_next'] = False
        log('  PRX-02: порядок хода сдвинут (очередь смещена)')
    deaths_before = STATE['deaths']
    log(f'════ ЦИКЛ {c} ════ живых {len(alive_list())}, призраков {len(ghosts())}')
    tk = int(MODS.get('teny_k', 0) or 0)
    for g in ghosts():
        g['tokens'] += 2 if MODS.get('tokens2') else 1
        if tk >= 2 and DRAW_TENY and not MODS.get('teny_off'):
            g['ghostcards'] = [DRAW_TENY.pop() for _ in range(min(tk, len(DRAW_TENY)))]
            g['ghostcard'] = None
            log(f'  👻 P{g["seat"]}: +1 жетон (итого {g["tokens"]}), {len(g["ghostcards"])} карт мёртвых: '
                + ', '.join('«%s»' % tg for tg, _ in g['ghostcards']))
        elif DRAW_TENY and not MODS.get('teny_off'):
            g['ghostcard'] = DRAW_TENY.pop()
            log(f'  👻 P{g["seat"]}: +1 жетон (итого {g["tokens"]}), карта мёртвых «{g["ghostcard"][1].split("—")[0].strip()}…»')
        else:
            log(f'  👻 P{g["seat"]}: +1 жетон (итого {g["tokens"]})')
    if not MODS.get('bets_off'): ghost_bets()
    for g in ghosts():
        ghost_shop(g)
        if not MODS.get('teny_off'):
            if g.get('ghostcards'):
                for card in g['ghostcards'][:]: ghost_use_card(g, card)
                g['ghostcards'] = []
            else: ghost_use_card(g)
    STATE['cur'] = None
    if c >= 2 and not MODS.get('obmen_off'):
        for p in alive_list():
            p['obmen'] = rng.choice(G.OBMEN)
    if c >= 4: try_token_revive()
    if VARIANT == 'market':
        for q in alive_list(): q['tokens'] += 1
    if VARIANT == 'bounty' and len(alive_list()) >= 2:
        t = rng.choice(alive_list()); STATE['bounty_seat'] = t['seat']
        T('bounty'); dispute('bounty')
        log(f'  🎯 BOUNTY: заказ на P{t["seat"]} — ранивший его тянет карту')
    if VARIANT == 'conclave' and len(alive_list()) >= 3:
        lv = alive_list(); t = rng.choice(lv)
        votes_for = sum(1 for q in lv if q is not t and rng.random() < 0.5)
        STATE['votes'] += 1; T('vote')
        log(f'  🗳 КОНКЛАВ: голосование об изгнании P{t["seat"]} — за {votes_for} из {len(lv) - 1}')
        if votes_for * 2 >= len(lv):
            STATE['expels'] += 1
            STATE['cur'] = t; dispute('vote'); STATE['cur'] = None
            check_death(t, 'голосование конклава', 'конклав')
    if VARIANT == 'duel' and len(alive_list()) >= 2:
        lv = alive_list()[:]; rng.shuffle(lv)
        for i in range(0, len(lv) - 1, 2):
            a, b = lv[i], lv[i + 1]
            ra, rb = d20(), d20()
            ea, eb = mod_roll(a, ra, 'рпди'), mod_roll(b, rb, 'рпди')
            STATE['duels'] += 1; T('duel')
            log(f'  ⚔ ДУЭЛЬ: P{a["seat"]} ({ea}) против P{b["seat"]} ({eb})')
            if ea > eb: wound(b, 1, a['name'])
            elif eb > ea: wound(a, 1, b['name'])
    for p in P:
        p['heal_taken'] = 0
        if not p['frozen'] and not p['gcycle']: p['no_target'] = False
    order = alive_list()
    if STATE['queue_shift'] and len(order) > 1:
        order = order[1:] + [order[0]]
    for p in order:
        if p['alive']: turn(p, c)
    STATE['cur'] = None
    if MODS.get('weird'):
        for q in alive_list():
            if prof_tag(q) == 'idletax' and q['idletax_used'] != c:
                idles = [by_seat(s) for s in sorted(STATE['idle_seats'])
                         if by_seat(s)['alive'] and by_seat(s) is not q]
                if idles and rng.random() < 0.6 * q['pr'].get('prof_p', 0.75):
                    t = rng.choice(idles); cc = closed_cards(t)
                    if cc:
                        k, card = rng.choice(cc); t['hand'][k].remove(card)
                        q['hand'].setdefault(k, []).append(card)
                        q['cards_gained'] += 1; t['cards_lost'] += 1
                    q['idletax_used'] = c; prof_use(q, 'idletax')
                    T('weird'); STATE['weird_events'] += 1
                    log(f'  PRX-07: P{q["seat"]} забирает карту у P{t["seat"]}, сэкономившего действия')
    log(f'  Конец цикла {c}: обмен и карты мёртвых — в сброс')
    T('breaks')
    cd = STATE['deaths'] - deaths_before
    resolve_bets(cd)
    if VARIANT == 'pole' and 2 <= c <= 4 and alive_list():
        v = rng.choice(alive_list())
        log(f'  ⚡ ПОЛЕ СУЖАЕТСЯ: P{v["seat"]} попадает в кромку — +1 ОР')
        before = STATE['deaths']
        wound(v, 1, 'поле')
        if STATE['deaths'] > before:
            STATE['field_deaths'] += 1
            cd += 1
    if VARIANT == 'hrono' and c in (2, 3, 4):
        rotate_hands()
    if c >= 2 and not STATE['player_death'] and not MODS.get('harvest_off') and len(alive_list()) >= 2:
        k = min(MODS.get('harvest_k', 1), len(alive_list()))
        if STATE.get('harvest_x2'): k = min(k * 2, len(alive_list()))
        STATE['harvests'] += 1
        for v in rng.sample(sorted(alive_list(), key=lambda x: x['seat']), k):
            log(f'  🌾 ЖАТВА: за цикл никто не умер от действий игроков — случайная смерть: P{v["seat"]}')
            check_death(v, 'жатва', 'Жатва')
            cd += 1
    if VARIANT == 'plague' and c >= 2:
        hits = 0
        for q in alive_list():
            if rng.random() < 0.35:
                hits += 1; wound(q, 1, 'среда')
        if hits:
            STATE['plagues'] += hits; T('plague', hits)
            log(f'  ☣ ЧУМА: среда задела {hits} игр. (+1 ОР каждому)')
    if VARIANT == 'timer':
        STATE['S'] = max(1, STATE['S'] - 1); STATE['timer_ticks'] += 1; T('timer_tick')
        log(f'  ⏳ ТАЙМЕР: порог конца снижен до S={STATE["S"]}')
    if VARIANT in FORCED_END and c >= 5 and STATE['end_cycle'] is None:
        s = send()
        over = len(alive_list()) - s
        if over > 0:
            log(f'  🎲 ФИНАЛ СИТУАЦИИ: рандомный выбор убийства оставшихся — погибнет {over}')
            for v in rng.sample(alive_list(), over):
                check_death(v, 'финал', 'ситуация')
            STATE['forced'] = True
    if VARIANT in ('amkary', 'amkary2'):
        teams_alive = set(q['team'] for q in alive_list())
        if len(teams_alive) == 1 and len(alive_list()) >= 1:
            STATE['team_win'] = True
            STATE['end_cycle'] = c
            log(f'  🏁 Осталась одна команда — конец игры')
            return False
        if VARIANT == 'amkary2' and len(alive_list()) <= 1:
            STATE['end_cycle'] = c
            return False
        if VARIANT == 'amkary2':
            log(f'  (режим «на уничтожение»: порог S не проверяется, игра идёт до последней команды)')
            return True
    STATE['max_cycle_deaths'] = max(STATE['max_cycle_deaths'], cd)
    alive_n = len(alive_list())
    log(f'  Живых после цикла {c}: {alive_n} (порог конца {send()})')
    if alive_n <= send():
        STATE['end_cycle'] = c
        return False
    return True

def run_game(seed, n, variant, mods=None):
    LOG.clear()
    setup(seed, n, variant, mods)
    log(f'ПАРТИЯ «БЛИЦ БОЙ» — {n} игроков, seed={seed}, ситуация: {VNAME[variant]}')
    T('setup')
    c = 1
    while c <= 12:
        if not run_cycle(c): break
        c += 1
    if STATE['end_cycle'] is None: STATE['end_cycle'] = c
    win = [p['seat'] for p in alive_list()]
    log(f'ИТОГ: игра окончена в цикле {STATE["end_cycle"]}. Победили места: {win}')
    return dict(n=n, variant=variant, seed=seed, end=STATE['end_cycle'], deaths=STATE['deaths'],
                roll_dist=dict(STATE['rolls']), max_cycle_deaths=STATE['max_cycle_deaths'],
                no_win=(len(win) == 0), stall=(STATE['end_cycle'] >= 12),
                alive=len(win), win=win, harvests=STATE['harvests'], token_revive=STATE['token_revive'],
                spec_revive=STATE['spec_revive'], avoid=STATE['avoid_saved'], bets_hit=STATE['bet_hits'],
                mass=STATE['mass_count'], nat1=STATE['nat1'], nat20=STATE['nat20'],
                first_death=STATE['first_death_cycle'], forced=STATE['forced'],
                team_win=STATE['team_win'], rotations=STATE['rotations'], field_deaths=STATE['field_deaths'],
                S=STATE['S'], W=STATE['W'], S0=STATE['S0'], dth=STATE['dth'],
                nspec=STATE['nspec'], teny_k=max(1, int(MODS.get('teny_k', 0) or 1)),
                T={k: (round(v, 2) if isinstance(v, float) else v) for k, v in STATE['T'].items()},
                spec_uses=STATE['spec_uses'], prof_uses=STATE['prof_uses'], ghost_uses=STATE['ghost_uses'],
                obmen_uses=STATE['obmen_uses'], collect_total=STATE['collect_total'],
                weird_events=STATE['weird_events'], reflects=STATE['reflects'],
                second_lives=STATE['second_lives'], hoard_cards=STATE['hoard_cards'],
                votes=STATE['votes'], duels=STATE['duels'], market_buys=STATE['market_buys'],
                plagues=STATE['plagues'], expels=STATE['expels'], vetoes=STATE['vetoes'],
                dups=STATE['dups'], timer_ticks=STATE['timer_ticks'],
                cards_gained=sum(p['cards_gained'] for p in P),
                cards_lost=sum(p['cards_lost'] for p in P),
                prof_agg=profile_agg(), seats=seat_rows())

def profile_agg():
    """Агрегаты по профилям поведения (пункты 6-7 исследования)."""
    out = {}
    for p in P:
        a = out.setdefault(p['pkey'], dict(n=0, alive=0, kills=0, or_sum=0, gained=0, lost=0,
                                           specs=0, profs=0, collect=0, obmen=0, wasted=0,
                                           tokens=0, revived=0))
        a['n'] += 1
        a['alive'] += 1 if p['alive'] else 0
        a['kills'] += p['kills']
        a['or_sum'] += p['or_']
        a['gained'] += p['cards_gained']; a['lost'] += p['cards_lost']
        a['specs'] += p['spec_uses']; a['profs'] += p['prof_uses']
        a['collect'] += p['collect_n']; a['obmen'] += p['obmen_uses']
        a['wasted'] += p['wasted']; a['tokens'] += p['tokens']
        a['revived'] += 1 if p['resurrected'] else 0
    return out

def seat_rows():
    return [dict(seat=p['seat'], pkey=p['pkey'], prof=p['prof'][0], alive=p['alive'], or_=p['or_'],
                 kills=p['kills'], gained=p['cards_gained'], lost=p['cards_lost'],
                 specs=p['spec_uses'], profs=p['prof_uses'], collect=p['collect_n'],
                 tokens=p['tokens'], died=p['died_cycle']) for p in P]

def main():
    mods = None
    for a in sys.argv[1:]:
        if a.startswith('{'):
            mods = json.loads(a)
    st = run_game(SEED, N, VARIANT, mods)
    if not QUIET:
        print('\n'.join(LOG))
    print('STATS=' + json.dumps(st, ensure_ascii=False))

if __name__ == '__main__':
    main()
