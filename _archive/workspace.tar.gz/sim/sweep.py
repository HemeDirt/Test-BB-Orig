import subprocess, sys, re
best = []
for seed in range(1, 501):
    out = subprocess.run([sys.executable, 'sim/game_sim.py', str(seed), '--quiet'], capture_output=True, text=True).stdout.strip()
    m = re.match(r'SCORE=(-?\d+) first_death=(\S+) end=(\S+) harvest=(\S+) bets_hit=(\S+) revive=(\S+) specrevive=(\S+) avoid=(\S+) deaths=(\S+)', out)
    if not m: continue
    sc, fd, end, hv, bh, rv, srv, av, dt = m.groups()
    score = int(sc)
    bonus = 0
    if rv == 'True': bonus += 6
    if srv == 'True': bonus += 1
    best.append((score+bonus, seed, out))
best.sort(reverse=True)
for b in best[:15]:
    print(b[0], b[1], b[2])
