# -*- coding: utf-8 -*-
"""sweep8 — полная матрица 8-пунктного исследования.

58 конфигураций × N=2..20 × 120 сидов ≈ 132 тыс. партий.
Выход: sim/sweep8_results.json  (агрегаты + суммы счётчиков T + prof_agg).
"""
import sys, os, json, time, statistics
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim8

SEEDS = range(1, 121)
NS = list(range(2, 21))

W = {'weird': True}
W2 = {'weird': True, 'spec2': True}

CONFIGS = [
    # --- ядро / пункт 1: профессии, спецкарты, тени, мультиспецкарты ---
    ('base',           'base', {}),
    ('weird',          'base', dict(W)),
    ('weird_spec2',    'base', dict(W2)),
    ('weird_s2tk2',    'base', dict(W2, teny_k=2)),
    ('weird_max',      'base', {'weird': True, 'spec3': True, 'teny_k': 3, 'prof_all': True, 'spec_hot': True}),
    ('spec2',          'base', {'spec2': True}),
    ('spec3',          'base', {'spec3': True}),
    ('tk2',            'base', {'teny_k': 2}),
    ('tk3',            'base', {'teny_k': 3}),
    ('pool1000',       'base', {'pool': 'sim1000'}),
    ('pool1k_weird',   'base', {'pool': 'sim1000', 'weird': True, 'spec2': True, 'teny_k': 2}),
    ('prof_all',       'base', {'prof_all': True}),
    ('prof_all_weird', 'base', {'weird': True, 'prof_all': True}),
    # --- пункт 3: новые модификаторы ---
    ('collect',        'base', {'collect': True}),
    ('escalation',     'base', {'escalation': True}),
    ('dth2',           'base', {'dth': 2}),
    ('dth4',           'base', {'dth': 4}),
    ('draft2',         'base', {'draft': 2}),
    ('spec_any',       'base', {'spec_any': True}),
    ('spec_hot',       'base', {'spec_hot': True}),
    ('tokens2',        'base', {'tokens2': True}),
    ('harvest_off',    'base', {'harvest_off': True}),
    ('rpdi_plus1',     'base', {'rpdi_extra': 1}),
    ('s_third',        'base', {'s_third': True}),
    ('open_hands',     'base', {'open_hands': True}),
    # --- пункт 4: собирательство ---
    ('hoard_all',      'base', {'profile': 'hoard'}),
    ('hoard_collect',  'base', {'profile': 'hoard', 'collect': True}),
    ('collect_only',   'base', {'collect_only': True}),
    # --- пункты 6-7: профили и пресеты ---
    ('profile_aggr',   'base', {'profile': 'aggr'}),
    ('profile_turtle', 'base', {'profile': 'turtle'}),
    ('profile_medic',  'base', {'profile': 'medic'}),
    ('profile_chaos',  'base', {'profile': 'chaos'}),
    ('preset_party',   'base', {'preset': 'party'}),
    ('preset_meat',    'base', {'preset': 'meat'}),
    ('preset_coop',    'base', {'preset': 'coop'}),
    ('preset_intrigue','base', {'preset': 'intrigue'}),
    ('preset_survive', 'base', {'preset': 'survive'}),
    ('preset_newbie',  'base', {'preset': 'newbie'}),
    ('preset_maxweird','base', {'preset': 'maxweird', 'weird': True, 'spec2': True}),
    ('preset_mixed',   'base', {'preset': 'mixed'}),
    ('mixed_weird',    'base', {'preset': 'mixed', 'weird': True, 'spec2': True}),
    # --- пункт 5: новые ситуации ---
    ('fog',            'fog', {}),
    ('timer',          'timer', {}),
    ('bounty',         'bounty', {}),
    ('silent',         'silent', {}),
    ('plague',         'plague', {}),
    ('market',         'market', {}),
    ('arena',          'arena', {}),
    ('conclave',       'conclave', {}),
    ('heirloom',       'heirloom', {}),
    ('duel',           'duel', {}),
    ('fog_weird',      'fog', dict(W2)),
    ('timer_weird',    'timer', dict(W2)),
    ('plague_weird',   'plague', dict(W2)),
    ('market_weird',   'market', dict(W2)),
    ('arena_weird',    'arena', dict(W2)),
    ('conclave_weird', 'conclave', dict(W2)),
    ('duel_weird',     'duel', dict(W2)),
    # --- legacy-ситуации (для сравнения и модели времени) ---
    ('plane',          'plane', {}),
    ('tomato',         'tomato', {}),
    ('pole',           'pole', {}),
    ('purg',           'purg', {}),
    ('amkary',         'amkary', {}),
    ('amkary2',        'amkary2', {}),
    ('hrono',          'hrono', {}),
]

MEAN_KEYS = ['deaths', 'alive', 'harvests', 'mass', 'spec_uses', 'prof_uses', 'ghost_uses',
             'obmen_uses', 'collect_total', 'weird_events', 'hoard_cards', 'cards_gained',
             'cards_lost', 'reflects', 'second_lives', 'votes', 'duels', 'market_buys',
             'plagues', 'expels', 'vetoes', 'dups', 'timer_ticks', 'bets_hit']

def pct(sorted_vals, q):
    if not sorted_vals: return None
    i = min(len(sorted_vals) - 1, max(0, int(round(q * (len(sorted_vals) - 1)))))
    return sorted_vals[i]

def agg(rows, n):
    ends = sorted(r['end'] for r in rows)
    fd = [r['first_death'] for r in rows if r['first_death'] is not None]
    out = dict(games=len(rows), n=n,
               end_mean=round(statistics.mean(ends), 2),
               end_p10=pct(ends, 0.10), end_p50=pct(ends, 0.50), end_p90=pct(ends, 0.90),
               deaths_mean=round(statistics.mean(r['deaths'] for r in rows), 2),
               alive_mean=round(statistics.mean(r['alive'] for r in rows), 2),
               stall_rate=round(sum(r['stall'] for r in rows) / len(rows), 3),
               no_win_rate=round(sum(r['no_win'] for r in rows) / len(rows), 3),
               harvests_mean=round(statistics.mean(r['harvests'] for r in rows), 2),
               first_death_mean=round(statistics.mean(fd), 2) if fd else None,
               mass_mean=round(statistics.mean(r['mass'] for r in rows), 2),
               avoid_rate=round(sum(1 for r in rows if r['avoid']) / len(rows), 3),
               forced_rate=round(sum(r['forced'] for r in rows) / len(rows), 3),
               team_win_rate=round(sum(r['team_win'] for r in rows) / len(rows), 3),
               nat1_rate=round(sum(r['nat1'] for r in rows) / len(rows), 3),
               nat20_rate=round(sum(r['nat20'] for r in rows) / len(rows), 3))
    for k in MEAN_KEYS:
        out[k] = round(statistics.mean(r.get(k, 0) for r in rows), 2)
    # счётчики времени: суммы по всем партиям ячейки
    T = {}
    for r in rows:
        for k, v in r['T'].items(): T[k] = T.get(k, 0) + v
    out['T_sum'] = {k: (round(v, 1) if isinstance(v, float) else v) for k, v in T.items()}
    # агрегаты профилей
    PA = {}
    for r in rows:
        for pk, a in r['prof_agg'].items():
            b = PA.get(pk)
            if b is None:
                PA[pk] = dict(a)
            else:
                for k2, v2 in a.items(): b[k2] = b.get(k2, 0) + v2
    out['prof_agg'] = PA
    return out

def main():
    t0 = time.time()
    res = {}
    total = len(CONFIGS) * len(NS) * len(list(SEEDS))
    done = 0
    for name, variant, mods in CONFIGS:
        res[name] = {'variant': variant, 'mods': mods, 'by_n': {}}
        for n in NS:
            rows = []
            for s in SEEDS:
                rows.append(sim8.run_game(s * 7919 + n * 131, n, variant, mods))
            res[name]['by_n'][str(n)] = agg(rows, n)
            done += len(rows)
        print(f'{name:16s} done  ({time.time()-t0:6.1f}s, {done}/{total})', flush=True)
    meta = dict(seeds=len(list(SEEDS)), ns=NS, games_total=done,
                elapsed_s=round(time.time() - t0, 1), configs=len(CONFIGS))
    out = {'meta': meta, 'configs': res}
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sweep8_results.json'),
              'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False)
    print('TOTAL', done, 'games in', meta['elapsed_s'], 's')

if __name__ == '__main__':
    main()
