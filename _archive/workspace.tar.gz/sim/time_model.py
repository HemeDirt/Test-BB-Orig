# -*- coding: utf-8 -*-
"""time_model — модель реальной длительности партии «БЛИЦ БОЙ» (пункт 2).

Идея: симулятор считает события партии (ходы, броски, раскрытия, заявки,
спецкарты, карты мёртвых, споры как ожидания, перерывы между циклами…),
каждое событие стоит секунд реального времени; профиль игрока даёт
множитель к «думанию», «рассказыванию» и «болтовне»; ведущий ускоряет
или замедляет немеханические компоненты (host factor); при большом столе
часть стоимости хода перекрывается (игроки думают в чужой ход).

Калибровка: базовая партия N=8 при host=1.0 принимается равной 60 минут
(середина наблюдаемого диапазона 30 мин – 2 ч).

Вход:  sim/sweep8_results.json
Выход: sim/time_results.json
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(open(os.path.join(HERE, 'sweep8_results.json'), encoding='utf-8'))
C = D['configs']

# базовые стоимости событий (сек на единицу счётчика), ДО калибровки
COST = {
    'turns': 4.0, 'think_u': 16.0, 'chatter_u': 9.0, 'narrate_u': 18.0,
    'rolls': 3.5, 'reveals': 12.0, 'specs': 30.0, 'ghost_cards': 22.0,
    'profs': 18.0, 'obmen': 15.0, 'disputes_e': 55.0, 'discuss_e': 40.0,
    'deaths': 18.0, 'revives': 50.0, 'breaks': 70.0, 'bets': 10.0,
    'shop': 8.0, 'vote': 45.0, 'duel': 20.0, 'market': 12.0, 'plague': 8.0,
    'veto': 35.0, 'weird': 20.0, 'collect': 15.0, 'wounds': 6.0,
    'crit_fail': 25.0, 'crit_kill': 25.0, 'immunity': 15.0,
    'skip_turns': 6.0, 'act_wasted': 8.0, 'bounty_hit': 12.0,
    'timer_tick': 10.0, 'bet_hits': 12.0, 'mass_ok': 15.0, 'mass_fail': 20.0,
    'selfheal_ok': 8.0, 'heal_ok': 10.0, 'heal_fail': 12.0,
    'steal_ok': 10.0, 'steal_fail': 14.0, 'humiliate_ok': 12.0, 'humiliate_fail': 14.0,
    'collect_fail': 8.0, 'acted': 0.0, 'cycles': 0.0, 'table_a': 0.0,
    'table_b': 0.0, 'table_v': 0.0, 'rpds': 0.0,
}
DEFAULT_COST = 4.0
# компоненты, которые сжимает или растягивает ведущий (host factor):
# раздумья, болтовня, споры, обсуждения, перерывы, рассказ эффектов
HOSTED = ('think_u', 'chatter_u', 'disputes_e', 'discuss_e', 'breaks', 'turns',
          'narrate_u', 'reveals', 'specs', 'ghost_cards', 'profs', 'obmen')
# компоненты хода, перекрывающиеся при большом столе: стоимость события
# падает как (8/N)**OEXP при N>8 (и слегка растёт при N<8)
OVL = ('turns', 'think_u', 'chatter_u', 'narrate_u', 'rolls', 'reveals', 'obmen',
       'profs', 'specs', 'ghost_cards', 'collect', 'acted', 'skip_turns',
       'act_wasted', 'bets', 'shop')
OEXP = 0.9
HOSTS = {'host_fast': 0.70, 'host_norm': 1.0, 'host_slow': 1.45}

def overlap(n):
    if n > 8:
        return (8.0 / n) ** OEXP
    return (8.0 / n) ** (OEXP * 0.55)

def setup_cost(n):
    """Раздача карт, выдача ролей, объяснение правил (сек)."""
    return 150.0 + 22.0 * n

def game_seconds(tsum, games, n, host=1.0, scale=1.0):
    s = setup_cost(n)
    ov = overlap(n)
    per = {k: v / games for k, v in tsum.items()}
    for k, v in per.items():
        if k == 'setup':
            continue
        c = COST.get(k, DEFAULT_COST)
        if k in HOSTED:
            c *= host
        if k in OVL:
            c *= ov
        s += c * v
    return s * scale

def calibrate():
    cell = C['base']['by_n']['8']
    raw = game_seconds(cell['T_sum'], cell['games'], 8, 1.0, 1.0)
    return 3600.0 / raw, raw

def breakdown(tsum, games, n, host, scale):
    per = {k: v / games for k, v in tsum.items()}
    ov = overlap(n)
    out = {'setup': setup_cost(n) * scale}
    for k, v in per.items():
        if k == 'setup':
            continue
        c = COST.get(k, DEFAULT_COST) * (host if k in HOSTED else 1.0) * \
            (ov if k in OVL else 1.0) * scale
        if c * v > 0:
            out[k] = out.get(k, 0.0) + c * v
    return {k: round(v, 1) for k, v in sorted(out.items(), key=lambda kv: -kv[1])}

TIME_CFGS = ['base', 'weird', 'weird_max', 'pool1000', 'pool1k_weird',
             'collect', 'hoard_all', 'collect_only',
             'preset_party', 'preset_meat', 'preset_coop', 'preset_intrigue',
             'preset_survive', 'preset_newbie', 'preset_maxweird', 'preset_mixed', 'mixed_weird',
             'timer', 'duel', 'arena', 'conclave', 'plague', 'market', 'silent',
             'fog', 'bounty', 'heirloom',
             'plane', 'tomato', 'pole', 'purg', 'amkary', 'hrono',
             'dth2', 'dth4', 'rpdi_plus1', 's_third', 'tokens2', 'harvest_off']
NS = [str(n) for n in range(2, 21)]

def main():
    scale, raw = calibrate()
    res = {'calibration': {'base_n8_raw_s': round(raw, 1), 'scale': round(scale, 4),
                            'target_s': 3600, 'host_factors': HOSTS, 'oexp': OEXP,
                            'setup_formula': '150 + 22*N сек'},
           'costs_scaled': {k: round(v * scale, 2) for k, v in COST.items() if v},
           'by_config': {}, 'breakdowns': {}}
    for cfg in TIME_CFGS:
        if cfg not in C:
            continue
        res['by_config'][cfg] = {}
        for n in NS:
            cell = C[cfg]['by_n'][n]
            row = {'cycles': cell['end_mean']}
            for hk, hv in HOSTS.items():
                row[hk] = round(game_seconds(cell['T_sum'], cell['games'], int(n), hv, scale) / 60.0, 1)
            res['by_config'][cfg][n] = row
    for cfg, n in [('base', '8'), ('base', '15'), ('base', '20'), ('base', '4'),
                   ('preset_maxweird', '8'), ('preset_party', '8'), ('preset_coop', '8'),
                   ('weird_max', '8'), ('collect_only', '8'), ('timer', '8'), ('duel', '8')]:
        if cfg in C:
            cell = C[cfg]['by_n'][n]
            res['breakdowns'][cfg + '@' + n] = breakdown(cell['T_sum'], cell['games'], int(n), 1.0, scale)
    with open(os.path.join(HERE, 'time_results.json'), 'w', encoding='utf-8') as f:
        json.dump(res, f, ensure_ascii=False, indent=1)

    print('scale = %.4f (base@N8 host=1.0 = 60.0 мин)' % scale)
    print()
    print('Минуты (host_norm) по N:')
    print('config            ' + ''.join(' N%3d' % n for n in [2, 4, 6, 8, 10, 12, 15, 20]))
    for cfg in ['base', 'weird_max', 'preset_party', 'preset_meat', 'preset_coop',
                'preset_survive', 'preset_maxweird', 'collect_only', 'hoard_all',
                'timer', 'duel', 'arena', 'conclave', 'plague', 'market', 'silent',
                'plane', 'purg', 'hrono', 's_third', 'rpdi_plus1', 'tokens2']:
        if cfg not in res['by_config']:
            continue
        line = '%-18s' % cfg
        for n in [2, 4, 6, 8, 10, 12, 15, 20]:
            line += ' %4.0f' % res['by_config'][cfg][str(n)]['host_norm']
        print(line)
    print()
    print('Влияние ведущего (base):')
    for n in [4, 6, 8, 10, 12, 15, 20]:
        r = res['by_config']['base'][str(n)]
        print('  N%2d: fast %5.0f | norm %5.0f | slow %5.0f мин' % (n, r['host_fast'], r['host_norm'], r['host_slow']))
    print()
    print('Структура времени base@N8 (мин):')
    bd = res['breakdowns']['base@8']
    tot = sum(bd.values())
    for k, v in list(bd.items())[:14]:
        print('  %-14s %6.1f мин  (%4.1f%%)' % (k, v / 60, v / tot * 100))

if __name__ == '__main__':
    main()
