# -*- coding: utf-8 -*-
"""Массовый прогон: базовая игра на N=2..20 + варианты ситуаций.
Usage: python3 sim/sweep_n.py [SEEDS_PER_CFG]
"""
import sys, os, json, statistics
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_n

SEEDS = int(sys.argv[1]) if len(sys.argv) > 1 else 240

def agg(rows):
    n = len(rows)
    def mean(k): return round(sum(r[k] for r in rows) / n, 2)
    def mean_nn(k):
        vals = [r[k] for r in rows if r[k] is not None]
        return round(sum(vals) / len(vals), 2) if vals else None
    def pct(k): return round(100 * sum(1 for r in rows if r[k]) / n, 1)
    return dict(games=n, end_mean=mean('end'), deaths_mean=mean('deaths'),
                alive_mean=mean('alive'), first_death_mean=mean_nn('first_death'),
                nodeath_pct=round(100 * sum(1 for r in rows if r['first_death'] is None) / n, 1),
                harvest_pct=pct('harvests'), harvest_mean=mean('harvests'),
                revive_pct=round(100 * sum(1 for r in rows if r['token_revive'] or r['spec_revive']) / n, 1),
                avoid_pct=pct('avoid'), bets_pct=pct('bets_hit'), mass_pct=pct('mass'),
                nat1_pct=pct('nat1'), nat20_pct=pct('nat20'), forced_pct=pct('forced'),
                teamwin_pct=pct('team_win'))

out = {}
base_rows = {}
for n in range(2, 21):
    rows = [sim_n.run_game(s, n, 'base') for s in range(1, SEEDS + 1)]
    base_rows[n] = rows
    out[f'base_n{n}'] = agg(rows)
    print(f'base N={n:2d}: end~{out[f"base_n{n}"]["end_mean"]} deaths~{out[f"base_n{n}"]["deaths_mean"]} alive~{out[f"base_n{n}"]["alive_mean"]} harvest%={out[f"base_n{n}"]["harvest_pct"]} revive%={out[f"base_n{n}"]["revive_pct"]} mass%={out[f"base_n{n}"]["mass_pct"]}', flush=True)

VCFG = [('plane', 10), ('tomato', 4), ('tomato', 12), ('pole', 8), ('purg', 8), ('purg', 12), ('amkary', 12), ('amkary', 16), ('hrono', 8), ('hrono', 16)]
for var, n in VCFG:
    rows = [sim_n.run_game(s, n, var) for s in range(1, SEEDS + 1)]
    out[f'{var}_n{n}'] = agg(rows)
    a = out[f'{var}_n{n}']
    print(f'{var:7s} N={n:2d}: end~{a["end_mean"]} deaths~{a["deaths_mean"]} alive~{a["alive_mean"]} harvest%={a["harvest_pct"]} forced%={a["forced_pct"]} teamwin%={a["teamwin_pct"]}', flush=True)

json.dump(out, open('sim/sweep_n_results.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('saved sim/sweep_n_results.json')
