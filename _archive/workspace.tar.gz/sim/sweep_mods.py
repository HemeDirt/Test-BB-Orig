# -*- coding: utf-8 -*-
"""Матрица мод-симуляций: локальные изменения правил x количество игроков.
Usage: python3 sim/sweep_mods.py [SEEDS]
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sim_n

SEEDS = int(sys.argv[1]) if len(sys.argv) > 1 else 200

CONFIGS = []
for n in (4, 6, 8, 10, 12, 15):
    CONFIGS.append((f'base_n{n}', 'base', n, {}))
for n in (4, 5, 6, 8, 10, 12, 15):
    CONFIGS.append((f'harvest_off_n{n}', 'base', n, {'harvest_off': True}))
for n in (6, 8, 10):
    CONFIGS.append((f'harvest2_n{n}', 'base', n, {'harvest_k': 2}))
for n in (6, 8, 10):
    CONFIGS.append((f'rpdi2_n{n}', 'base', n, {'rpdi_extra': 1}))
for n in (6, 8):
    CONFIGS.append((f'rpds_off_n{n}', 'base', n, {'rpds_off': True}))
for n in (6, 8, 10):
    CONFIGS.append((f's_plus1_n{n}', 'base', n, {'s_plus1': True}))
for n in (8, 12):
    CONFIGS.append((f's_third_n{n}', 'base', n, {'s_third': True}))
CONFIGS += [
    ('healcap_off_n8', 'base', 8, {'healcap_off': True}),
    ('tokens2_n8', 'base', 8, {'tokens2': True}),
    ('revive5_n8', 'base', 8, {'revive5': True}),
    ('revive5_n12', 'base', 12, {'revive5': True}),
    ('mass_low_n8', 'base', 8, {'mass_low': True}),
    ('mass_low_n12', 'base', 12, {'mass_low': True}),
    ('obmen_off_n8', 'base', 8, {'obmen_off': True}),
    ('teny_off_n8', 'base', 8, {'teny_off': True}),
    ('bets_off_n8', 'base', 8, {'bets_off': True}),
    ('amkary2_n8', 'amkary2', 8, {}),
    ('amkary2_n12', 'amkary2', 12, {}),
    ('amkary2_n16', 'amkary2', 16, {}),
]

def agg(rows):
    n = len(rows)
    def mean(k): return round(sum(r[k] for r in rows) / n, 2)
    def pct(k): return round(100 * sum(1 for r in rows if r[k]) / n, 1)
    rolls = {}
    for r in rows:
        for f, c in r['roll_dist'].items():
            rolls[int(f)] = rolls.get(int(f), 0) + c
    return dict(games=n, end_mean=mean('end'), deaths_mean=mean('deaths'), alive_mean=mean('alive'),
                harvest_pct=pct('harvests'), revive_pct=round(100*sum(1 for r in rows if r['token_revive'] or r['spec_revive'])/n,1),
                mass_pct=pct('mass'), bets_pct=pct('bets_hit'), stall_pct=pct('stall'),
                nowin_pct=pct('no_win'), blood_pct=round(100*sum(1 for r in rows if r['max_cycle_deaths']>=3)/n,1),
                teamwin_pct=pct('team_win'), rolls=rolls)

out = {}
for name, var, n, mods in CONFIGS:
    rows = [sim_n.run_game(s, n, var, mods) for s in range(1, SEEDS+1)]
    out[name] = agg(rows)
    a = out[name]
    print(f"{name:18s} end~{a['end_mean']:4} deaths~{a['deaths_mean']:5} alive~{a['alive_mean']:4} "
          f"harv%={a['harvest_pct']:5} rev%={a['revive_pct']:5} stall%={a['stall_pct']:4} nowin%={a['nowin_pct']:4} "
          f"blood3+%={a['blood_pct']:4} team%={a['teamwin_pct']:4}", flush=True)

json.dump(out, open('sim/sweep_mods_results.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
# честность кубика: суммарное распределение по всем прогонaм базы
tot = {}
for k, v in out.items():
    for f, c in v['rolls'].items():
        tot[f] = tot.get(f, 0) + c
allr = sum(tot.values())
print('\nРАСПРЕДЕЛЕНИЕ d20 по всем прогонам (%):')
for f in range(1, 21):
    print(f'  {f:2d}: {100*tot.get(f,0)/allr:5.2f}%  ({"#"*int(100*tot.get(f,0)/allr/0.5)})')
print('всего бросков:', allr)
json.dump({'total_rolls': allr, 'dist': tot}, open('sim/dice_dist.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
